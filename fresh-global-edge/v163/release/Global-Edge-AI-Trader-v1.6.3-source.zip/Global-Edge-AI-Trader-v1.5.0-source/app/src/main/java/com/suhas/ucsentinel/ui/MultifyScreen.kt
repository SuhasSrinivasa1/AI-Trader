package com.suhas.globaledgeai.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun MultifyCompactScreen(state:UiState,vm:MainViewModel,padding:PaddingValues){
    val ctx=LocalContext.current
    val events=state.multifyEvents.sortedByDescending{it.capturedAt}
    val evaluated=events.count{it.evaluation!="PENDING"}
    val positive=events.count{it.evaluation=="EDGE_POSITIVE"}
    val negative=events.count{it.evaluation=="EDGE_NEGATIVE"}
    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(horizontal=14.dp),
        verticalArrangement=Arrangement.spacedBy(10.dp),
        contentPadding=PaddingValues(top=12.dp,bottom=24.dp)
    ){
        item{
            Column(verticalArrangement=Arrangement.spacedBy(4.dp)){
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Column(Modifier.weight(1f)){
                        Text("Multify",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                        Text("Event intelligence • capture first, qualify with market evidence",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(if(state.multifyListenerEnabled)"LISTENING" else "OFF",color=if(state.multifyListenerEnabled)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)
                }
                Text("Captured ${events.size} • evaluated $evaluated • positive edge $positive • negative edge $negative",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item{
            ElevatedCard(Modifier.fillMaxWidth()){
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                    Text("Notification listener",style=MaterialTheme.typography.titleMedium)
                    Text(
                        if(state.multifyListenerEnabled)
                            "Enabled. Only notifications identified as Multify are persisted. BUY/SELL, NSE symbol, timestamp and signal price are parsed when present."
                        else
                            "Notification access is required before the app can capture Multify calls. Enable Global Edge AI Trader in Android Notification access.",
                        style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))},modifier=Modifier.weight(1f)){
                            Text(if(state.multifyListenerEnabled)"Notification access" else "Enable listener")
                        }
                        OutlinedButton(onClick=vm::replayMultifyNow,enabled=!state.busy&&state.authenticated&&events.any{it.evaluation=="PENDING"},modifier=Modifier.weight(1f)){
                            Text("Replay pending")
                        }
                    }
                }
            }
        }
        item{
            ElevatedCard(Modifier.fillMaxWidth()){
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("How this lane works",style=MaterialTheme.typography.titleMedium)
                    Text("1. Capture the Multify event immediately.  2. Measure price/volume response and signal decay.  3. Re-evaluate after 15 minutes and again off-market.  4. Feed the result into research; do not blindly place an order.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Manual-order-only remains in force. A Multify event is evidence, not an execution command.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)
                }
            }
        }
        if(events.isEmpty()){
            item{
                ElevatedCard(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                        Text("No Multify events captured yet",fontWeight=FontWeight.Bold)
                        Text("After notification access is enabled, the next matching Multify notification will appear here automatically. No manual refresh is required.",color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }else{
            item{Text("RECENT EVENTS",style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            items(events.take(100),key={it.id}){e->
                ElevatedCard(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                            Text(e.symbol.ifBlank{"Unparsed symbol"},fontWeight=FontWeight.Bold)
                            Text(e.direction.ifBlank{"EVENT"},color=if(e.direction=="SELL")MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,fontWeight=FontWeight.SemiBold)
                        }
                        Text(formatIstTimestamp(e.capturedAt)+(if(e.signalPrice>0)" • signal ₹${"%.2f".format(e.signalPrice)}" else ""),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        Text((e.title+" "+e.text).trim().take(220),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        if(e.evaluation=="PENDING"){
                            Text("PENDING REPLAY",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.tertiary)
                        }else{
                            Text("${e.evaluation.replace('_',' ')} • 15m ${"%+.2f".format(e.return15mPct)}% • MFE ${"%+.2f".format(e.mfePct)}% • MAE ${"%+.2f".format(e.maePct)}%",style=MaterialTheme.typography.labelSmall,color=if(e.evaluation=="EDGE_POSITIVE")MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
