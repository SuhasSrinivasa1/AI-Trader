package com.suhas.globaledgeai.notifications

import android.app.Notification
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.suhas.globaledgeai.diagnostics.DiagnosticLog
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

data class MultifyEvent(
    val id:String,
    val capturedAt:Long,
    val packageName:String,
    val title:String,
    val text:String,
    val direction:String,
    val symbol:String,
    val signalPrice:Double,
    val evaluatedAt:Long=0L,
    val return15mPct:Double=0.0,
    val mfePct:Double=0.0,
    val maePct:Double=0.0,
    val evaluation:String="PENDING"
)

object MultifyEventStore {
    private const val PREFS="global_edge_multify_events"
    private const val KEY="events_json"
    private const val MAX_EVENTS=400

    fun listenerEnabled(context:Context):Boolean {
        val enabled=Settings.Secure.getString(context.contentResolver,"enabled_notification_listeners").orEmpty()
        return enabled.split(':').any{it.startsWith(context.packageName+"/") && it.contains("MultifyNotificationService")}
    }

    @Synchronized fun recent(context:Context,limit:Int=200):List<MultifyEvent> = load(context).sortedByDescending{it.capturedAt}.take(limit)

    @Synchronized fun capture(context:Context,event:MultifyEvent):Boolean {
        val rows=load(context).toMutableList()
        if(rows.any{it.id==event.id})return false
        rows.add(event)
        save(context,rows.sortedByDescending{it.capturedAt}.take(MAX_EVENTS))
        return true
    }

    @Synchronized fun update(context:Context,event:MultifyEvent){
        val rows=load(context).toMutableList();val i=rows.indexOfFirst{it.id==event.id}
        if(i>=0){rows[i]=event;save(context,rows)}
    }

    private fun load(context:Context):List<MultifyEvent>{
        val raw=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY,"[]")?:"[]"
        return runCatching{
            val a=JSONArray(raw);buildList{
                for(i in 0 until a.length()){
                    val o=a.optJSONObject(i)?:continue
                    add(MultifyEvent(
                        id=o.optString("id"),capturedAt=o.optLong("capturedAt"),packageName=o.optString("packageName"),title=o.optString("title"),text=o.optString("text"),
                        direction=o.optString("direction"),symbol=o.optString("symbol"),signalPrice=o.optDouble("signalPrice",0.0),evaluatedAt=o.optLong("evaluatedAt"),
                        return15mPct=o.optDouble("return15mPct",0.0),mfePct=o.optDouble("mfePct",0.0),maePct=o.optDouble("maePct",0.0),evaluation=o.optString("evaluation","PENDING")
                    ))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun save(context:Context,rows:List<MultifyEvent>){
        val a=JSONArray();rows.take(MAX_EVENTS).forEach{e->
            a.put(JSONObject().apply{
                put("id",e.id);put("capturedAt",e.capturedAt);put("packageName",e.packageName);put("title",e.title);put("text",e.text);put("direction",e.direction);put("symbol",e.symbol);put("signalPrice",e.signalPrice)
                put("evaluatedAt",e.evaluatedAt);put("return15mPct",e.return15mPct);put("mfePct",e.mfePct);put("maePct",e.maePct);put("evaluation",e.evaluation)
            })
        }
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()
    }

    fun idFor(packageName:String,postedAt:Long,title:String,text:String):String{
        val bytes=MessageDigest.getInstance("SHA-256").digest("$packageName|$postedAt|$title|$text".toByteArray())
        return bytes.take(10).joinToString(""){"%02x".format(it)}
    }
}

class MultifyNotificationService:NotificationListenerService(){
    override fun onNotificationPosted(sbn:StatusBarNotification){
        val n=sbn.notification?:return
        val title=n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text=listOf(
            n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
            n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty(),
            n.extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        ).firstOrNull{it.isNotBlank()}.orEmpty().trim()
        val pkg=sbn.packageName.orEmpty()
        val combined="$title $text"
        if(!pkg.lowercase(Locale.ROOT).contains("multify") && !combined.lowercase(Locale.ROOT).contains("multify"))return
        if(combined.isBlank())return

        val direction=Regex("\\b(BUY|SELL)\\b",RegexOption.IGNORE_CASE).find(combined)?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT).orEmpty()
        val symbol=parseSymbol(combined,direction)
        val price=Regex("(?:@|\\bAT\\b|\\bPRICE\\b)\\s*[:=-]?\\s*₹?\\s*(\\d+(?:\\.\\d+)?)",RegexOption.IGNORE_CASE)
            .find(combined)?.groupValues?.getOrNull(1)?.toDoubleOrNull()?:0.0
        val event=MultifyEvent(
            id=MultifyEventStore.idFor(pkg,sbn.postTime,title,text),capturedAt=sbn.postTime,packageName=pkg,title=title.take(120),text=text.take(600),
            direction=direction,symbol=symbol,signalPrice=price
        )
        if(MultifyEventStore.capture(applicationContext,event)){
            DiagnosticLog.log(applicationContext,"MULTIFY","captured ${event.direction.ifBlank{"EVENT"}} ${event.symbol.ifBlank{"unparsed"}} • package=$pkg")
        }
    }

    private fun parseSymbol(raw:String,direction:String):String{
        val u=raw.uppercase(Locale.ROOT)
        val candidates=mutableListOf<String>()
        if(direction.isNotBlank()){
            Regex("\\b$direction\\b\\s*[:=-]?\\s*(?:NSE[:\\s-]*)?([A-Z][A-Z0-9&.-]{1,19})").find(u)?.groupValues?.getOrNull(1)?.let(candidates::add)
        }
        Regex("\\bNSE[:\\s-]+([A-Z][A-Z0-9&.-]{1,19})\\b").find(u)?.groupValues?.getOrNull(1)?.let(candidates::add)
        val blocked=setOf("BUY","SELL","NSE","CASH","INTRADAY","TARGET","STOP","LOSS","PRICE","CALL","MULTIFY","CMP","ABOVE","BELOW")
        return candidates.firstOrNull{it !in blocked}.orEmpty()
    }
}
