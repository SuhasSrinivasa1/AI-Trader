package com.suhas.globaledgeai.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.suhas.globaledgeai.GlobalEdgeApplication
import com.suhas.globaledgeai.diagnostics.DiagnosticLog

class MultifySignalWorker(appContext:Context,params:WorkerParameters):CoroutineWorker(appContext,params){
    override suspend fun doWork():Result{
        val eventId=inputData.getString("event_id").orEmpty()
        if(eventId.isBlank())return Result.success()
        val repo=(applicationContext as GlobalEdgeApplication).repository
        return try{
            val decision=repo.processMultifyEvent(eventId)
            DiagnosticLog.log(applicationContext,"MULTIFY-FAST","${decision?.symbol?:"?"} • ${decision?.tier?:"SKIP"} • ${decision?.direction?:"NONE"} • score=${decision?.score?:0.0} • ${decision?.strategyTag.orEmpty()}")
            Result.success()
        }catch(t:Throwable){
            DiagnosticLog.log(applicationContext,"MULTIFY-FAST","event $eventId immediate analysis failed",t)
            if(repo.isAuthenticationFailure(t))Result.retry() else Result.success()
        }
    }
}
