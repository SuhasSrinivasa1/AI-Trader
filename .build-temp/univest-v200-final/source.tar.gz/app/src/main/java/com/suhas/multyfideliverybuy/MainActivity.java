package com.suhas.multyfideliverybuy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(5, 9, 14);
    private static final int CARD = Color.rgb(14, 23, 33);
    private static final int CARD2 = Color.rgb(20, 32, 44);
    private static final int TEXT = Color.rgb(241, 246, 250);
    private static final int MUTED = Color.rgb(153, 169, 183);
    private static final int ACCENT = Color.rgb(53, 224, 193);
    private static final int BLUE = Color.rgb(92, 132, 255);
    private static final int WARN = Color.rgb(255, 190, 90);
    private static final int BAD = Color.rgb(255, 112, 112);
    private static final int REQUEST_EXPORT = 8200;

    private Switch armSwitch, liveModeSwitch;
    private EditText apiKeyInput, totpSecretInput, expectedIpInput;
    private TextView sourceStatus, connectionStatus, lastAction, holdingsStatus, recentEvents, listenerStatus, notificationHistory, tradeHistory, errorHistory;
    private File pendingExport;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean resumed;

    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            if (!resumed) return;
            refreshStatus();
            handler.postDelayed(this, 2500L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());
        loadSettings(); requestNotificationPermissionIfNeeded();
        new Thread(() -> {
            try { UnivestManager.migrateLegacyRules(getApplicationContext()); } catch (Throwable ignored) {}
        }, "univest-v2-migration").start();
    }

    @Override protected void onResume() {
        super.onResume(); resumed = true; handler.removeCallbacks(refresher); refresher.run();
    }

    @Override protected void onPause() {
        resumed = false; handler.removeCallbacks(refresher); super.onPause();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16), dp(18), dp(16), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("UNIVEST AUTOTRADE", 26, TEXT, true); root.addView(title);
        TextView version = text("v2.0.0 • FINAL", 12, ACCENT, true); root.addView(version, margins(0,4,0,4));
        TextView subtitle = text("Univest-only notification automation • PAPER/LIVE control • CNC delivery only • no intraday orders", 14, MUTED, false); root.addView(subtitle, margins(0,0,0,14));

        LinearLayout lock = card();
        lock.addView(section("LOCKED SAFETY CONTRACT"));
        sourceStatus = text("Source: Univest only", 14, TEXT, true); lock.addView(sourceStatus, margins(0,8,0,2));
        lock.addView(text("Package lock: com.univest.capp", 13, MUTED, false));
        lock.addView(text("Product lock: NSE CASH / CNC DELIVERY ONLY", 13, ACCENT, true), margins(0,5,0,0));
        lock.addView(text("New eligible recommendation: ₹20,000", 13, TEXT, false), margins(0,8,0,0));
        lock.addView(text("Back in range / ideal buy range: +₹5,000", 13, TEXT, false));
        lock.addView(text("Book profit / exit: sell full matching CNC holding", 13, TEXT, false));
        root.addView(lock, margins(0,0,0,12));

        LinearLayout control = card();
        control.addView(section("EXECUTION MODE & CONTROL"));
        liveModeSwitch = new Switch(this); liveModeSwitch.setText("LIVE TRADING — REAL CNC ORDERS"); liveModeSwitch.setTextColor(TEXT); liveModeSwitch.setTextSize(15); liveModeSwitch.setPadding(0,dp(7),0,dp(2));
        liveModeSwitch.setOnCheckedChangeListener((button, checked) -> onLiveModeChanged(checked));
        control.addView(liveModeSwitch);
        control.addView(text("OFF = PAPER MODE. PAPER reads/parses/logs Univest notifications and simulates actions without sending Groww orders.", 12, MUTED, false), margins(0,0,0,8));
        armSwitch = new Switch(this); armSwitch.setText("ARM UNIVEST AUTOTRADE"); armSwitch.setTextColor(TEXT); armSwitch.setTextSize(16); armSwitch.setPadding(0,dp(7),0,dp(7));
        armSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked && AppPrefs.isLiveTrading(this) && !AppPrefs.isReadyForBuy(this)) {
                armSwitch.setOnCheckedChangeListener(null); armSwitch.setChecked(false); AppPrefs.setUnivestEnabled(this, false);
                Toast.makeText(this, "LIVE mode requires TEST CONNECTION first. PAPER mode can be armed without Groww execution readiness.", Toast.LENGTH_LONG).show();
                armSwitch.setOnCheckedChangeListener((b,c) -> onArmChanged(c));
                return;
            }
            onArmChanged(checked);
        });
        control.addView(armSwitch);
        connectionStatus = text("Connection status", 13, MUTED, false); control.addView(connectionStatus, margins(0,5,0,0));
        listenerStatus = text("Notification access", 13, MUTED, false); control.addView(listenerStatus, margins(0,4,0,0));
        Button access = button("OPEN NOTIFICATION ACCESS", BLUE); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))); control.addView(access, margins(0,10,0,0));
        root.addView(control, margins(0,0,0,12));

        LinearLayout status = card(); status.addView(section("CURRENT STATUS"));
        lastAction = text("No action yet.", 14, TEXT, false); status.addView(lastAction, margins(0,8,0,0));
        holdingsStatus = text("No tracked Univest campaigns.", 13, MUTED, false); status.addView(holdingsStatus, margins(0,10,0,0));
        root.addView(status, margins(0,0,0,12));

        LinearLayout diagnostics = card(); diagnostics.addView(section("DIAGNOSTICS & EXPORT"));
        diagnostics.addView(text("Every Univest notification is archived. Parser decisions, symbol mapping, broker responses, successful/failed orders and errors are also logged. API keys, TOTP secrets and access tokens are never exported.", 13, MUTED, false), margins(0,8,0,10));
        Button export = button("EXPORT COMPLETE DEBUG ZIP", ACCENT); export.setTextColor(Color.rgb(3,12,12)); export.setOnClickListener(v -> createExport()); diagnostics.addView(export);
        recentEvents = text("No runtime events recorded yet.", 12, MUTED, false); diagnostics.addView(recentEvents, margins(0,12,0,0));
        root.addView(diagnostics, margins(0,0,0,12));

        LinearLayout notifications = card(); notifications.addView(section("NOTIFICATION INBOX"));
        notifications.addView(text("Latest official Univest notifications. Every notification is archived even when it does not trigger a trade.", 12, MUTED, false), margins(0,6,0,8));
        notificationHistory = text("No notifications recorded yet.", 12, TEXT, false); notifications.addView(notificationHistory);
        root.addView(notifications, margins(0,0,0,12));

        LinearLayout trades = card(); trades.addView(section("TRADE JOURNAL"));
        trades.addView(text("Latest PAPER/LIVE buy, add and sell outcomes with broker order details when available.", 12, MUTED, false), margins(0,6,0,8));
        tradeHistory = text("No trade events recorded yet.", 12, TEXT, false); trades.addView(tradeHistory);
        root.addView(trades, margins(0,0,0,12));

        LinearLayout errors = card(); errors.addView(section("ERROR DIAGNOSTICS"));
        errors.addView(text("Symbol mapping failures, readiness blocks, broker failures and runtime exceptions appear here and in the export ZIP.", 12, MUTED, false), margins(0,6,0,8));
        errorHistory = text("No errors recorded yet.", 12, WARN, false); errors.addView(errorHistory);
        root.addView(errors, margins(0,0,0,12));

        LinearLayout settings = card(); settings.addView(section("GROWW CONNECTION"));
        settings.addView(text("Kept from the working app settings. Save only if you need to change credentials/static IP.", 12, MUTED, false), margins(0,6,0,8));
        apiKeyInput = input("Groww API key / TOTP token", true); settings.addView(apiKeyInput);
        totpSecretInput = input("TOTP Base32 secret", true); settings.addView(totpSecretInput, margins(0,8,0,0));
        expectedIpInput = input("Groww-whitelisted static public IP", false); settings.addView(expectedIpInput, margins(0,8,0,0));
        Button save = button("SAVE CONNECTION SETTINGS", BLUE); save.setOnClickListener(v -> saveSettings()); settings.addView(save, margins(0,10,0,0));
        Button test = button("TEST CONNECTION & REFRESH AUTH", ACCENT); test.setTextColor(Color.rgb(3,12,12)); test.setOnClickListener(v -> testConnection(test)); settings.addView(test, margins(0,8,0,0));
        Button instruments = button("REFRESH NSE INSTRUMENT MAP", CARD2); instruments.setOnClickListener(v -> refreshInstruments(instruments)); settings.addView(instruments, margins(0,8,0,0));
        root.addView(settings);

        root.addView(text("Build contract: Univest package source lock • PAPER/LIVE mode • <=3-month equity entries • CNC only • ₹20K initial • ₹5K back-in-range • official book-profit/exit sells holding • exportable diagnostics.", 11, MUTED, false), margins(2,14,2,0));
        return scroll;
    }

    private void onArmChanged(boolean checked) {
        AppPrefs.setUnivestEnabled(this, checked);
        String mode = AppPrefs.isLiveTrading(this) ? "LIVE" : "PAPER";
        String msg = checked ? "UNIVEST AUTOTRADE ARMED • " + mode + " mode • source and CNC locks active." : "UNIVEST AUTOTRADE DISARMED • " + mode + " mode.";
        AppPrefs.setUnivestStatus(this, msg); DiagnosticsStore.runtime(this, checked ? "ARMED" : "DISARMED", "", msg); refreshStatus();
    }

    private void onLiveModeChanged(boolean live) {
        if (live && !AppPrefs.isReadyForBuy(this)) {
            liveModeSwitch.setOnCheckedChangeListener(null); liveModeSwitch.setChecked(false); liveModeSwitch.setOnCheckedChangeListener((b,c) -> onLiveModeChanged(c));
            AppPrefs.setLiveTrading(this, false); AppPrefs.setUnivestEnabled(this, false);
            Toast.makeText(this, "LIVE mode blocked until TEST CONNECTION confirms Groww authentication and the whitelisted static IP.", Toast.LENGTH_LONG).show();
            refreshStatus(); return;
        }
        AppPrefs.setLiveTrading(this, live); AppPrefs.setUnivestEnabled(this, false);
        String msg = "Execution mode changed to " + (live ? "LIVE — real CNC orders" : "PAPER — no broker orders") + ". Automation DISARMED; ARM again when ready.";
        AppPrefs.setUnivestStatus(this, msg); DiagnosticsStore.runtime(this, "EXECUTION_MODE_CHANGED", "", msg); refreshStatus();
    }

    private void loadSettings() {
        apiKeyInput.setText(AppPrefs.getApiKey(this)); totpSecretInput.setText(AppPrefs.getTotpSecret(this)); expectedIpInput.setText(AppPrefs.getExpectedStaticIp(this));
    }

    private void saveSettings() {
        AppPrefs.setApiKey(this, apiKeyInput.getText().toString()); AppPrefs.setTotpSecret(this, totpSecretInput.getText().toString()); AppPrefs.setExpectedStaticIp(this, expectedIpInput.getText().toString());
        AppPrefs.invalidateConnectionReadiness(this); AppPrefs.setUnivestEnabled(this, false);
        DiagnosticsStore.runtime(this, "CONNECTION_SETTINGS_CHANGED", "", "Connection readiness invalidated. Run TEST CONNECTION before arming.");
        Toast.makeText(this, "Saved. Run TEST CONNECTION before arming.", Toast.LENGTH_LONG).show(); refreshStatus();
    }

    private void testConnection(Button button) {
        button.setEnabled(false); button.setText("TESTING…");
        new Thread(() -> {
            NetworkCheck.Result ip = NetworkCheck.detectAndCompare(getApplicationContext());
            GrowwClient.Result auth = ip.match ? GrowwClient.refreshAndTestAuthentication(getApplicationContext()) : new GrowwClient.Result(false,false,0,"Authentication not tested because static IP does not match.");
            DiagnosticsStore.broker(getApplicationContext(), "STATIC_IP_TEST", "", ip.match, ip.message);
            DiagnosticsStore.broker(getApplicationContext(), "GROWW_AUTH_TEST", "", auth.success, auth.message);
            runOnUiThread(() -> { button.setEnabled(true); button.setText("TEST CONNECTION & REFRESH AUTH"); refreshStatus(); Toast.makeText(this, ip.message + "\n" + auth.message, Toast.LENGTH_LONG).show(); });
        }, "univest-connection-test").start();
    }

    private void refreshInstruments(Button button) {
        button.setEnabled(false); button.setText("REFRESHING…");
        new Thread(() -> {
            boolean changed = InstrumentRepository.refreshIfStale(getApplicationContext());
            List<InstrumentRepository.Instrument> list = InstrumentRepository.load(getApplicationContext());
            DiagnosticsStore.runtime(getApplicationContext(), "INSTRUMENT_MAP_REFRESH", "", "NSE CASH instruments available: " + list.size() + (changed ? " • downloaded fresh map" : " • cache/current asset used"));
            runOnUiThread(() -> { button.setEnabled(true); button.setText("REFRESH NSE INSTRUMENT MAP"); Toast.makeText(this, "Instrument map ready: " + list.size() + " NSE CASH symbols.", Toast.LENGTH_LONG).show(); refreshStatus(); });
        }, "univest-instrument-refresh").start();
    }

    private void createExport() {
        Toast.makeText(this, "Preparing diagnostic ZIP…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                pendingExport = DiagnosticsStore.createExport(getApplicationContext());
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE, pendingExport.getName()); startActivityForResult(i, REQUEST_EXPORT);
                });
            } catch (Exception e) {
                DiagnosticsStore.error(getApplicationContext(), "EXPORT_FAILED", "", "Unable to create diagnostics ZIP.", e);
                runOnUiThread(() -> Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }, "univest-export").start();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK || data == null || data.getData() == null || pendingExport == null) return;
        Uri uri = data.getData();
        try (FileInputStream in = new FileInputStream(pendingExport); OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("Cannot open selected export destination.");
            byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) out.write(b,0,n); out.flush();
            Toast.makeText(this, "Diagnostic ZIP exported. You can upload this file to ChatGPT for full analysis.", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Unable to save export: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void refreshStatus() {
        boolean enabled = AppPrefs.isUnivestEnabled(this);
        boolean live = AppPrefs.isLiveTrading(this);
        liveModeSwitch.setOnCheckedChangeListener(null); liveModeSwitch.setChecked(live); liveModeSwitch.setOnCheckedChangeListener((b,c) -> onLiveModeChanged(c));
        armSwitch.setOnCheckedChangeListener(null); armSwitch.setChecked(enabled); armSwitch.setOnCheckedChangeListener((b,c) -> {
            if (c && AppPrefs.isLiveTrading(this) && !AppPrefs.isReadyForBuy(this)) { b.setChecked(false); AppPrefs.setUnivestEnabled(this,false); Toast.makeText(this,"LIVE mode requires TEST CONNECTION first.",Toast.LENGTH_LONG).show(); return; }
            onArmChanged(c);
        });
        sourceStatus.setText("Source: LOCKED ✓ • official Univest app only • Mode: " + (live ? "LIVE" : "PAPER")); sourceStatus.setTextColor(ACCENT);
        boolean ready = AppPrefs.isReadyForBuy(this);
        connectionStatus.setText("Execution: " + (live ? "LIVE — real CNC orders" : "PAPER — no broker orders") + "\n" + (ready ? "Groww: READY ✓" : "Groww: NOT READY") + " • Static IP " + (AppPrefs.isStaticIpMatch(this) ? "MATCH ✓" : "not confirmed") + " • " + AppPrefs.getAuthTestMessage(this));
        connectionStatus.setTextColor(live ? (ready ? ACCENT : WARN) : MUTED);
        boolean listener = notificationAccessEnabled(); listenerStatus.setText("Notification access: " + (listener ? "ENABLED ✓" : "NOT ENABLED")); listenerStatus.setTextColor(listener ? ACCENT : BAD);
        String last = AppPrefs.getUnivestStatus(this); long at = AppPrefs.getUnivestStatusTime(this);
        lastAction.setText((enabled ? "ARMED" : "DISARMED") + "\n" + last + (at > 0 ? "\n" + stamp(at) : ""));
        List<UnivestStateStore.State> states = UnivestStateStore.all(this); StringBuilder sb = new StringBuilder();
        if (states.isEmpty()) sb.append("No tracked Univest campaigns.");
        else for (UnivestStateStore.State s : states) { if (sb.length()>0) sb.append("\n"); sb.append(s.symbol).append(" • ").append(s.phase).append(" • tracked qty ").append(s.quantity); }
        holdingsStatus.setText(sb.toString()); recentEvents.setText(DiagnosticsStore.recent(this, 6));
        notificationHistory.setText(DiagnosticsStore.recentStream(this, "notifications", 8));
        tradeHistory.setText(DiagnosticsStore.recentStream(this, "trades", 8));
        errorHistory.setText(DiagnosticsStore.recentStream(this, "errors", 8));
    }

    private boolean notificationAccessEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 700);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(14),dp(14),dp(14));
        GradientDrawable g = new GradientDrawable(); g.setColor(CARD); g.setCornerRadius(dp(16)); g.setStroke(dp(1), Color.rgb(31,48,62)); l.setBackground(g); return l;
    }
    private TextView section(String s) { TextView v=text(s,12,ACCENT,true); v.setLetterSpacing(0.08f); return v; }
    private TextView text(String s, int sp, int color, boolean bold) { TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setLineSpacing(0,1.12f); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private EditText input(String hint, boolean secret) { EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(105,123,138)); e.setTextColor(TEXT); e.setTextSize(14); e.setSingleLine(true); e.setPadding(dp(12),dp(10),dp(12),dp(10)); GradientDrawable g=new GradientDrawable(); g.setColor(CARD2); g.setCornerRadius(dp(10)); g.setStroke(dp(1),Color.rgb(44,63,78)); e.setBackground(g); if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); return e; }
    private Button button(String label, int color) { Button b=new Button(this); b.setText(label); b.setTextSize(13); b.setTextColor(TEXT); b.setAllCaps(false); GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(11)); b.setBackground(g); b.setGravity(Gravity.CENTER); return b; }
    private LinearLayout.LayoutParams margins(int l,int t,int r,int b) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p; }
    private int dp(int v) { return Math.round(v*getResources().getDisplayMetrics().density); }
    private String stamp(long ms) { return new SimpleDateFormat("dd MMM yyyy • hh:mm:ss a", Locale.US).format(new Date(ms)); }
}
