package com.suhas.multyfideliverybuy;

import android.content.Context;

import java.util.List;
import java.util.Locale;

final class UnivestManager {
    static final int ENTRY_BUDGET = 20000;
    static final int REENTRY_BUDGET = 5000;
    private static final long DUPLICATE_EXIT_GUARD_MS = 120000L;

    private UnivestManager() {}

    static void handle(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        if (signal == null) return;
        if (signal.type == UnivestParser.Type.ENTRY) handleEntry(context, signal, notificationPostTime);
        else if (signal.type == UnivestParser.Type.REENTRY) handleReentry(context, signal, notificationPostTime);
        else handleExit(context, signal, notificationPostTime);
    }

    static void handleEntry(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "ENTRY");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        if (!instrument.buyAllowed) {
            fail(context, "ENTRY_BUY_BLOCKED", symbol, "Groww instrument master marks buy_allowed=0.", null);
            return;
        }
        if (!UnivestStateStore.reserveNewEntry(context, symbol)) {
            UnivestStateStore.State existing = UnivestStateStore.get(context, symbol);
            String phase = existing == null ? "UNKNOWN" : existing.phase;
            status(context, "UNIVEST ENTRY DUPLICATE/ACTIVE IGNORED • " + symbol + " • state " + phase + ".");
            DiagnosticsStore.runtime(context, "ENTRY_DUPLICATE_IGNORED", symbol, "Recommendation cycle already open in state " + phase + ".");
            return;
        }

        DiagnosticsStore.runtime(context, "ENTRY_ACCEPTED", symbol, "Eligible <=3 month Univest recommendation • fixed ₹20,000 CNC delivery budget.");
        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketBuy(context, symbol, ENTRY_BUDGET, ref("UVE", symbol));
        if (!r.submitted) {
            UnivestStateStore.releasePendingEntry(context, symbol, "Groww CNC BUY not submitted: " + r.message);
            fail(context, "ENTRY_NOT_SUBMITTED", symbol, r.message, null);
            DiagnosticsStore.trade(context, "BUY_FAILED", symbol, r.message, r);
            return;
        }

        UnivestStateStore.State state = new UnivestStateStore.State();
        state.symbol = symbol;
        state.phase = r.filled && r.filledQuantity > 0 ? UnivestStateStore.ACTIVE : UnivestStateStore.ERROR;
        state.anchorPrice = r.averagePrice;
        state.tickSize = instrument.tickSize;
        state.quantity = Math.max(0, r.filledQuantity);
        state.principal = Math.max(0, r.averagePrice) * Math.max(0, r.filledQuantity);
        state.estimatedBuyCharges = state.principal > 0 ? DeliveryNetTarget.buyCharges(state.principal) : 0;
        state.averageLevel = 0;
        state.reentryUsed = false;
        state.exitOrderId = r.orderId;
        state.lastAction = r.filled
                ? "Initial ₹20,000 CNC delivery BUY executed • qty " + r.filledQuantity + " • avg ₹" + money(r.averagePrice)
                : "CNC BUY submitted but fill not confirmed • order " + r.orderId;
        UnivestStateStore.put(context, state);

        DiagnosticsStore.trade(context, r.filled ? "BUY_EXECUTED" : "BUY_SUBMITTED_FILL_UNCONFIRMED", symbol, state.lastAction, r);
        long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
        status(context, "UNIVEST CNC BUY " + (r.filled ? "EXECUTED" : "SUBMITTED") + " • " + symbol
                + " • ₹20,000 budget" + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
    }

    static void handleReentry(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "REENTRY");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        if (!instrument.buyAllowed) { fail(context, "REENTRY_BUY_BLOCKED", symbol, "Groww instrument master marks buy_allowed=0.", null); return; }

        GrowwClient.PositionSnapshot before = GrowwClient.getCncPosition(context, symbol);
        if (!before.success) { fail(context, "REENTRY_HOLDING_CHECK_FAILED", symbol, before.message, null); return; }
        if (before.quantity <= 0) {
            status(context, "UNIVEST BACK-IN-RANGE IGNORED • " + symbol + " • no CNC holding found.");
            DiagnosticsStore.runtime(context, "REENTRY_IGNORED_NO_HOLDING", symbol, before.message);
            return;
        }

        DiagnosticsStore.runtime(context, "REENTRY_ACCEPTED", symbol, "Back-in-range notification • fixed ₹5,000 CNC delivery add.");
        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketBuy(context, symbol, REENTRY_BUDGET, ref("UVR", symbol));
        if (!r.submitted) {
            fail(context, "REENTRY_NOT_SUBMITTED", symbol, r.message, null);
            DiagnosticsStore.trade(context, "REENTRY_BUY_FAILED", symbol, r.message, r);
            return;
        }

        UnivestStateStore.State state = UnivestStateStore.get(context, symbol);
        if (state == null) { state = new UnivestStateStore.State(); state.symbol = symbol; }
        state.phase = r.filled ? UnivestStateStore.ACTIVE : UnivestStateStore.ERROR;
        if (r.filled) {
            state.quantity = before.quantity + r.filledQuantity;
            state.principal = Math.max(0, state.principal) + Math.max(0, r.averagePrice) * Math.max(0, r.filledQuantity);
            state.reentryUsed = true;
            state.lastAction = "₹5,000 back-in-range CNC add executed • qty " + r.filledQuantity + " • avg ₹" + money(r.averagePrice);
        } else state.lastAction = "₹5,000 CNC add submitted but fill not confirmed • order " + r.orderId;
        UnivestStateStore.put(context, state);

        DiagnosticsStore.trade(context, r.filled ? "REENTRY_BUY_EXECUTED" : "REENTRY_FILL_UNCONFIRMED", symbol, state.lastAction, r);
        long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
        status(context, "UNIVEST ₹5,000 CNC RE-ENTRY " + (r.filled ? "EXECUTED" : "SUBMITTED") + " • " + symbol
                + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
    }

    static void handleExit(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "EXIT");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        UnivestStateStore.State state = UnivestStateStore.get(context, symbol);
        if (state != null && UnivestStateStore.EXITING_OFFICIAL.equals(state.phase)
                && System.currentTimeMillis() - state.updatedAt < DUPLICATE_EXIT_GUARD_MS) {
            DiagnosticsStore.runtime(context, "EXIT_DUPLICATE_GUARDED", symbol, "Recent official exit is already being processed.");
            return;
        }

        cancelLegacyTrackedOrders(context, state);
        GrowwClient.Result conflicts = GrowwClient.cancelOpenCncSellOrdersForSymbol(context, symbol);
        DiagnosticsStore.broker(context, "CANCEL_CONFLICTING_CNC_SELLS", symbol, conflicts.success || conflicts.unknown, conflicts.message);

        GrowwClient.PositionSnapshot holding = GrowwClient.getCncPosition(context, symbol);
        if (!holding.success) { fail(context, "EXIT_HOLDING_CHECK_FAILED", symbol, holding.message, null); return; }
        if (holding.quantity <= 0) {
            markExited(context, state, symbol, "Official Univest exit received; broker shows no CNC holding.");
            status(context, "UNIVEST BOOK PROFIT / EXIT • " + symbol + " • no holding found; nothing to sell.");
            DiagnosticsStore.runtime(context, "EXIT_NO_HOLDING", symbol, holding.message);
            return;
        }
        if (!instrument.sellAllowed) { fail(context, "EXIT_SELL_BLOCKED", symbol, "Groww instrument master marks sell_allowed=0.", null); return; }

        if (state == null) { state = new UnivestStateStore.State(); state.symbol = symbol; }
        state.phase = UnivestStateStore.EXITING_OFFICIAL;
        state.exitRequestedQty = holding.quantity;
        state.lastAction = "Official Univest book-profit/exit • CNC MARKET SELL requested for full broker holding qty " + holding.quantity;
        UnivestStateStore.put(context, state);

        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketSell(context, symbol, holding.quantity, ref("UVX", symbol));
        DiagnosticsStore.trade(context, r.submitted ? "SELL_SUBMITTED" : "SELL_FAILED", symbol, state.lastAction, r);
        if (!r.submitted) { fail(context, "EXIT_NOT_SUBMITTED", symbol, r.message, null); return; }

        GrowwClient.PositionSnapshot after = GrowwClient.getCncPosition(context, symbol);
        if (r.filled || (after.success && after.quantity == 0)) {
            markExited(context, state, symbol, "Official Univest exit executed • sold full CNC holding.");
            long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
            status(context, "UNIVEST CNC SELL EXECUTED • " + symbol + " • qty " + holding.quantity
                    + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
        } else {
            state.phase = UnivestStateStore.EXITING_OFFICIAL;
            state.exitOrderId = r.orderId;
            state.lastAction = "CNC SELL accepted; fill/position-zero not yet confirmed. " + r.message;
            UnivestStateStore.put(context, state);
            status(context, "UNIVEST SELL ACCEPTED — VERIFYING • " + symbol + " • " + r.message);
        }
    }

    static void migrateLegacyRules(Context context) {
        if (AppPrefs.isUnivestV2Migrated(context)) return;
        boolean allClean = true;
        for (UnivestStateStore.State state : UnivestStateStore.all(context)) {
            if (state.activeGttId != null && !state.activeGttId.isEmpty()) {
                GrowwClient.Result r = GrowwClient.cancelCashGtt(context, state.activeGttId);
                DiagnosticsStore.broker(context, "CANCEL_LEGACY_AVERAGE_GTT", state.symbol, r.success || r.unknown, r.message);
                if (r.success) { state.activeGttId = ""; state.activeGttKind = ""; state.activeGttQty = 0; state.activeGttPrice = 0; }
                else allClean = false;
            }
            if (state.protectiveStopGttId != null && !state.protectiveStopGttId.isEmpty()) {
                GrowwClient.Result r = GrowwClient.cancelCashGtt(context, state.protectiveStopGttId);
                DiagnosticsStore.broker(context, "CANCEL_LEGACY_STOP_GTT", state.symbol, r.success || r.unknown, r.message);
                if (r.success) { state.protectiveStopGttId = ""; state.protectiveStopPrice = 0; state.protectiveStopQty = 0; }
                else allClean = false;
            }
            UnivestStateStore.put(context, state);
        }
        if (allClean) {
            AppPrefs.setUnivestV2Migrated(context, true);
            DiagnosticsStore.runtime(context, "V2_RULE_MIGRATION_COMPLETE", "", "Legacy autonomous GTT averaging/stop rules disabled. v2 is notification-driven only.");
        }
    }

    static void reconcileAll(Context context) {
        // v2 deliberately has no autonomous profit-taking, averaging or intraday monitor.
        migrateLegacyRules(context);
    }

    private static InstrumentRepository.Instrument resolve(Context context, UnivestParser.Signal signal, String action) {
        try { InstrumentRepository.refreshIfStale(context); } catch (Throwable ignored) {}
        List<InstrumentRepository.Instrument> instruments = InstrumentRepository.load(context);
        InstrumentRepository.Instrument i = InstrumentRepository.resolve(instruments, signal.symbol);
        if (i != null) {
            if (!i.symbol.equalsIgnoreCase(signal.symbol)) {
                DiagnosticsStore.runtime(context, "SYMBOL_MAPPED", i.symbol, "Univest stock text '" + signal.symbol + "' mapped to NSE symbol " + i.symbol + " (" + i.name + ").");
            }
            return i;
        }
        List<String> suggestions = InstrumentRepository.suggestions(instruments, signal.symbol, 5);
        String msg = action + " symbol mapping failed for Univest stock text '" + signal.symbol + "'. Candidates: " + suggestions;
        fail(context, "SYMBOL_MAPPING_FAILED", signal.symbol, msg, null);
        return null;
    }

    private static void cancelLegacyTrackedOrders(Context context, UnivestStateStore.State s) {
        if (s == null) return;
        if (s.activeGttId != null && !s.activeGttId.isEmpty()) {
            GrowwClient.Result r = GrowwClient.cancelCashGtt(context, s.activeGttId);
            DiagnosticsStore.broker(context, "CANCEL_TRACKED_GTT_BEFORE_EXIT", s.symbol, r.success || r.unknown, r.message);
            if (r.success) s.activeGttId = "";
        }
        if (s.protectiveStopGttId != null && !s.protectiveStopGttId.isEmpty()) {
            GrowwClient.Result r = GrowwClient.cancelCashGtt(context, s.protectiveStopGttId);
            DiagnosticsStore.broker(context, "CANCEL_TRACKED_STOP_BEFORE_EXIT", s.symbol, r.success || r.unknown, r.message);
            if (r.success) s.protectiveStopGttId = "";
        }
        UnivestStateStore.put(context, s);
    }

    private static void markExited(Context c, UnivestStateStore.State s, String symbol, String message) {
        if (s == null) { s = new UnivestStateStore.State(); s.symbol = symbol; }
        s.phase = UnivestStateStore.EXITED; s.quantity = 0; s.principal = 0; s.estimatedBuyCharges = 0;
        s.exitRequestedQty = 0; s.activeGttId = ""; s.protectiveStopGttId = ""; s.lastAction = message;
        UnivestStateStore.put(c, s);
    }

    private static void fail(Context c, String event, String symbol, String message, Throwable t) {
        DiagnosticsStore.error(c, event, symbol, message, t);
        status(c, "UNIVEST ERROR • " + symbol + " • " + message);
    }

    private static void status(Context c, String text) {
        AppPrefs.setUnivestStatus(c, text);
        DiagnosticsStore.runtime(c, "STATUS", "", text);
    }

    private static String ref(String prefix, String symbol) {
        String s = (prefix + Long.toString(System.currentTimeMillis(), 36) + symbol).toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
        if (s.length() > 20) s = s.substring(0, 20);
        while (s.length() < 8) s += "0";
        return s;
    }
    private static String money(double v) { return String.format(Locale.US, "%.2f", v); }
}
