package com.suhas.multyfideliverybuy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Historical class name retained so Android keeps the existing notification-listener grant on upgrade.
 * v2 accepts notifications ONLY from the official Univest Android package com.univest.capp.
 */
public class MultyfiNotificationService extends NotificationListenerService {
    static final String UNIVEST_PACKAGE = "com.univest.capp";
    private final ExecutorService buyExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService exitExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate() {
        super.onCreate();
        buyExecutor.execute(() -> {
            try { UnivestManager.migrateLegacyRules(getApplicationContext()); }
            catch (Throwable t) { DiagnosticsStore.error(getApplicationContext(), "V2_MIGRATION_ERROR", "", "Legacy-rule cleanup failed.", t); }
        });
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String packageName = sbn.getPackageName() == null ? "" : sbn.getPackageName();

        // Hard source lock: notification text can never spoof the source application.
        if (!UNIVEST_PACKAGE.equals(packageName)) return;

        String combined = collectText(sbn.getNotification());
        DiagnosticsStore.notification(getApplicationContext(), packageName, combined);
        UnivestParser.Signal signal = UnivestParser.parse(combined);
        if (signal == null) {
            DiagnosticsStore.runtime(getApplicationContext(), "UNIVEST_NOTIFICATION_NO_TRADE", "",
                    "Notification stored but did not match an eligible <=3 month equity entry, back-in-range add, or equity book-profit/exit rule.");
            return;
        }

        if (!AppPrefs.isUnivestEnabled(getApplicationContext())) {
            String msg = "Ignored Univest " + signal.type + " • " + signal.symbol + " • automation is DISARMED.";
            AppPrefs.setUnivestStatus(getApplicationContext(), msg);
            DiagnosticsStore.runtime(getApplicationContext(), "SIGNAL_IGNORED_DISARMED", signal.symbol, msg);
            return;
        }

        final long postTime = sbn.getPostTime();
        if (signal.type == UnivestParser.Type.ENTRY || signal.type == UnivestParser.Type.REENTRY) {
            if (!AppPrefs.isReadyForBuy(getApplicationContext())) {
                String msg = "UNIVEST " + signal.type + " IGNORED • " + signal.symbol
                        + " • Groww/static-IP readiness is stale. Run TEST CONNECTION before ARMING.";
                AppPrefs.setUnivestStatus(getApplicationContext(), msg);
                DiagnosticsStore.error(getApplicationContext(), "BUY_READINESS_BLOCK", signal.symbol, msg, null);
                return;
            }
            if (signal.type == UnivestParser.Type.REENTRY) {
                String key = "reentry_" + shortHash(signal.rawText);
                if (!AppPrefs.claimRecent(getApplicationContext(), key, 120000L)) {
                    DiagnosticsStore.runtime(getApplicationContext(), "REENTRY_DUPLICATE_IGNORED", signal.symbol, "Identical back-in-range notification seen within 2 minutes.");
                    return;
                }
            }
            AppPrefs.setUnivestStatus(getApplicationContext(), "UNIVEST " + signal.type + " DETECTED • " + signal.symbol
                    + " • " + (signal.type == UnivestParser.Type.ENTRY ? "₹20,000" : "₹5,000") + " CNC delivery path queued.");
            buyExecutor.execute(() -> {
                UnivestManager.handle(getApplicationContext(), signal, postTime);
                showLocalStatus("UNIVEST " + signal.type, AppPrefs.getUnivestStatus(getApplicationContext()), true);
            });
            return;
        }

        // Exit is authoritative. We still attempt the sell even if the readiness timestamp is stale;
        // GrowwClient will refresh authentication if required and will log any broker rejection.
        if (!AppPrefs.isReadyForBuy(getApplicationContext())) {
            DiagnosticsStore.runtime(getApplicationContext(), "EXIT_READINESS_WARNING", signal.symbol,
                    "Groww/static-IP readiness flag is stale; official Univest exit will still be attempted.");
        }
        AppPrefs.setUnivestStatus(getApplicationContext(), "UNIVEST BOOK PROFIT / EXIT DETECTED • " + signal.symbol + " • full CNC holding sell queued.");
        exitExecutor.execute(() -> {
            UnivestManager.handle(getApplicationContext(), signal, postTime);
            showLocalStatus("UNIVEST EXIT", AppPrefs.getUnivestStatus(getApplicationContext()), true);
        });
    }

    @Override public void onDestroy() {
        buyExecutor.shutdown(); exitExecutor.shutdown(); super.onDestroy();
    }

    private String collectText(Notification n) {
        StringBuilder sb = new StringBuilder();
        append(sb, n.extras.getCharSequence(Notification.EXTRA_TITLE));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_TEXT));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_SUB_TEXT));
        CharSequence[] lines = n.extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) for (CharSequence line : lines) append(sb, line);
        return sb.toString();
    }
    private void append(StringBuilder sb, CharSequence value) {
        if (value == null) return; String s = value.toString().trim(); if (s.isEmpty()) return;
        if (sb.indexOf(s) >= 0) return; if (sb.length() > 0) sb.append('\n'); sb.append(s);
    }

    private void showLocalStatus(String title, String text, boolean ok) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE); if (nm == null) return;
        String channelId = "univest_status";
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(channelId, "Univest AutoTrade status", NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channelId) : new Notification.Builder(this);
        b.setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim).setAutoCancel(true);
        nm.notify((int) (System.currentTimeMillis() & 0x7FFFFFFF), b.build());
    }

    private static String shortHash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] d = md.digest((s == null ? "" : s).getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(); for (int i = 0; i < 8; i++) out.append(String.format(Locale.US, "%02x", d[i])); return out.toString();
        } catch (Exception e) { return Integer.toHexString((s == null ? "" : s).hashCode()); }
    }
}
