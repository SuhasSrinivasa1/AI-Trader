package com.suhas.multyfideliverybuy;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class DiagnosticsStore {
    private static final String DIR = "univest_diagnostics";
    private static final Object LOCK = new Object();
    private static final String[] STREAMS = {"notifications", "trades", "errors", "broker", "runtime"};

    private DiagnosticsStore() {}

    static void notification(Context c, String packageName, String raw) {
        JSONObject d = new JSONObject();
        put(d, "package", packageName); put(d, "raw", raw);
        append(c, "notifications", "NOTIFICATION_RECEIVED", "", d);
    }

    static void runtime(Context c, String event, String symbol, String message) {
        JSONObject d = new JSONObject(); put(d, "message", message);
        append(c, "runtime", event, symbol, d);
    }

    static void trade(Context c, String event, String symbol, String message, GrowwClient.ExecutionResult r) {
        JSONObject d = new JSONObject();
        put(d, "message", message);
        if (r != null) {
            put(d, "submitted", r.submitted); put(d, "filled", r.filled); put(d, "unknown", r.unknown);
            put(d, "orderId", r.orderId); put(d, "requestedQuantity", r.requestedQuantity);
            put(d, "filledQuantity", r.filledQuantity); put(d, "averagePrice", r.averagePrice);
            put(d, "sizingLtp", r.sizingLtp); put(d, "dispatchAtMillis", r.dispatchAtMillis);
            put(d, "brokerMessage", r.message);
        }
        append(c, "trades", event, symbol, d);
    }

    static void broker(Context c, String event, String symbol, boolean ok, String message) {
        JSONObject d = new JSONObject(); put(d, "ok", ok); put(d, "message", message);
        append(c, "broker", event, symbol, d);
    }

    static void error(Context c, String event, String symbol, String message, Throwable t) {
        JSONObject d = new JSONObject(); put(d, "message", message);
        if (t != null) { put(d, "exception", t.getClass().getName()); put(d, "exceptionMessage", t.getMessage()); }
        append(c, "errors", event, symbol, d);
    }

    private static void append(Context c, String stream, String event, String symbol, JSONObject detail) {
        synchronized (LOCK) {
            try {
                File dir = dir(c); if (!dir.exists()) dir.mkdirs();
                JSONObject row = new JSONObject();
                row.put("timestamp", iso(System.currentTimeMillis()));
                row.put("timestampMillis", System.currentTimeMillis());
                row.put("stream", stream); row.put("event", event);
                row.put("symbol", symbol == null ? "" : symbol); row.put("detail", detail == null ? new JSONObject() : detail);
                File f = new File(dir, stream + ".jsonl");
                try (Writer w = new OutputStreamWriter(new FileOutputStream(f, true), StandardCharsets.UTF_8)) {
                    w.write(row.toString()); w.write('\n');
                }
            } catch (Exception ignored) {}
        }
    }

    static String recent(Context c, int maxLines) {
        ArrayDeque<String> q = new ArrayDeque<>();
        File f = new File(dir(c), "runtime.jsonl");
        if (!f.exists()) return "No runtime events recorded yet.";
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) { q.addLast(line); while (q.size() > maxLines) q.removeFirst(); }
        } catch (Exception e) { return "Unable to read diagnostics: " + e.getMessage(); }
        StringBuilder out = new StringBuilder();
        for (String line : q) {
            try {
                JSONObject j = new JSONObject(line); JSONObject d = j.optJSONObject("detail");
                if (out.length() > 0) out.append("\n\n");
                out.append(j.optString("timestamp")).append("  ").append(j.optString("event"));
                String sym = j.optString("symbol"); if (!sym.isEmpty()) out.append(" • ").append(sym);
                if (d != null && !d.optString("message").isEmpty()) out.append("\n").append(d.optString("message"));
            } catch (Exception ignored) {}
        }
        return out.length() == 0 ? "No runtime events recorded yet." : out.toString();
    }

    static File createExport(Context c) throws Exception {
        synchronized (LOCK) {
            File out = new File(c.getCacheDir(), "Univest-Debug-" + fileStamp() + ".zip");
            try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
                File d = dir(c);
                for (String s : STREAMS) {
                    File f = new File(d, s + ".jsonl");
                    if (f.exists()) addFile(zip, f, s + ".jsonl");
                    else addText(zip, s + ".jsonl", "");
                }
                addText(zip, "snapshot.json", snapshot(c).toString(2));
                addText(zip, "README.txt",
                        "Univest AutoTrade diagnostic export\n" +
                        "Contains Univest notifications, parser/runtime decisions, broker outcomes, trades and errors.\n" +
                        "It intentionally does NOT export the Groww API key, TOTP secret or access token.\n");
            }
            return out;
        }
    }

    private static JSONObject snapshot(Context c) {
        JSONObject j = new JSONObject();
        try {
            j.put("app", "Univest AutoTrade"); j.put("version", "2.0.0"); j.put("versionCode", 200);
            j.put("sourcePackageLock", "com.univest.capp"); j.put("productLock", "CNC DELIVERY ONLY");
            j.put("entryBudget", UnivestManager.ENTRY_BUDGET); j.put("reentryBudget", UnivestManager.REENTRY_BUDGET);
            j.put("enabled", AppPrefs.isUnivestEnabled(c)); j.put("growwReady", AppPrefs.isReadyForBuy(c));
            j.put("staticIpMatch", AppPrefs.isStaticIpMatch(c)); j.put("lastDetectedIp", AppPrefs.getLastDetectedIp(c));
            j.put("lastStatus", AppPrefs.getUnivestStatus(c));
            JSONArray states = new JSONArray(); for (UnivestStateStore.State s : UnivestStateStore.all(c)) states.put(s.toJson());
            j.put("states", states);
        } catch (Exception ignored) {}
        return j;
    }

    static void clear(Context c) {
        synchronized (LOCK) {
            File d = dir(c); for (String s : STREAMS) { File f = new File(d, s + ".jsonl"); if (f.exists()) f.delete(); }
        }
    }

    private static File dir(Context c) { return new File(c.getFilesDir(), DIR); }
    private static void addFile(ZipOutputStream zip, File f, String name) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) zip.write(b, 0, n); }
        zip.closeEntry();
    }
    private static void addText(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name)); zip.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
    }
    private static void put(JSONObject j, String k, Object v) { try { j.put(k, v == null ? JSONObject.NULL : v); } catch (Exception ignored) {} }
    private static String iso(long ms) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); return f.format(new Date(ms));
    }
    private static String fileStamp() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); return f.format(new Date());
    }
}
