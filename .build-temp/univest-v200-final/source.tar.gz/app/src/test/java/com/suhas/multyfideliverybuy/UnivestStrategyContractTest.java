package com.suhas.multyfideliverybuy;

import org.junit.Test;
import static org.junit.Assert.*;

public class UnivestStrategyContractTest {
    @Test public void fixedBudgetsAreLocked() {
        assertEquals(20000, UnivestManager.ENTRY_BUDGET);
        assertEquals(5000, UnivestManager.REENTRY_BUDGET);
    }
    @Test public void exitedSymbolCanStartNewRecommendationCycle() {
        assertTrue(UnivestStateStore.canReservePhase(UnivestStateStore.EXITED));
        assertFalse(UnivestStateStore.canReservePhase(UnivestStateStore.ACTIVE));
        assertTrue(UnivestStateStore.canExecuteReservedPhase(UnivestStateStore.ENTRY_PENDING));
    }
    @Test public void companyNameNormalizationRemovesLegalSuffixes() {
        assertEquals("TATA MOTORS", InstrumentRepository.normalizedName("Tata Motors Limited"));
        assertEquals("TATA MOTORS", InstrumentRepository.normalizedName("TATA MOTORS LTD."));
    }
    @Test public void sourcePackageIsStrictlyUnivest() {
        assertEquals("com.univest.capp", MultyfiNotificationService.UNIVEST_PACKAGE);
    }
}
