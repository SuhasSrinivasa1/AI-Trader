package com.suhas.multyfideliverybuy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Historical class name retained so Android keeps the existing notification-listener grant on upgrade.
 * v2.0.2 accepts notifications ONLY from the official Univest package com.univest.capp.
 */
public class MultyfiNotificationService extends NotificationListenerService {
    static final String UNIVEST_PACKAGE = "com.univest.capp";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService maintenance = Executors.newSingleThreadScheduledExecutor();

    @Override public void onCreate() {
        super.onCreate();
        worker.execute(() -> {
            try { DiagnosticsStore.rotateIfNeeded(getApplicationContext()); UnivestManager.migrateLegacyRules(getApplicationContext()); UnivestManager.migrateV202(getApplicationContext()); drainPending(); UnivestManager.reconcileAll(getApplicationContext()); }
            catch (Throwable t) { DiagnosticsStore.error(getApplicationContext(), "V202_STARTUP_ERROR", "", "Startup reconciliation failed.", t); }
        });
        maintenance.scheduleWithFixedDelay(() -> worker.execute(() -> {
            try { DiagnosticsStore.rotateIfNeeded(getApplicationContext()); drainPending(); UnivestManager.reconcileAll(getApplicationContext()); }
            catch (Throwable t) { DiagnosticsStore.error(getApplicationContext(), "V202_MAINTENANCE_ERROR", "", "Background reconciliation failed.", t); }
        }), 60L, 60L, TimeUnit.SECONDS);
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String packageName = sbn.getPackageName() == null ? "" : sbn.getPackageName();
        if (!UNIVEST_PACKAGE.equals(packageName)) return; // Hard source lock.

        String combined = collectText(sbn.getNotification());
        if (combined.trim().isEmpty()) return;

        // Android/Univest can post the same visible notification twice a few milliseconds apart.
        // Archive/process it once in a short window, rather than filling the UI or double-dispatching.
        if (!AppPrefs.claimRecent(getApplicationContext(), "notif_" + shortHash(combined), 3000L)) return;

        UnivestParser.Signal signal = UnivestParser.parse(combined);
        DiagnosticsStore.notification(getApplicationContext(), packageName, combined, signal);
        if (signal == null) {
            DiagnosticsStore.runtime(getApplicationContext(), "UNIVEST_NOTIFICATION_NO_TRADE", "",
                    "Stored for audit only; not an eligible <=3 month equity entry, back-in-range add, or equity book-profit/exit signal.");
            return;
        }

        String signalKey = "signal_" + signal.type.name() + "_" + signal.symbol + "_" + shortHash(signal.rawText);
        if (!AppPrefs.claimRecent(getApplicationContext(), signalKey, 120000L)) {
            DiagnosticsStore.runtime(getApplicationContext(), "SIGNAL_DUPLICATE_IGNORED", signal.symbol,
                    "Identical parsed Univest signal seen within 2 minutes; first copy remains authoritative.");
            return;
        }

        if (!AppPrefs.isUnivestEnabled(getApplicationContext())) {
            String msg = "Ignored Univest " + signal.type + " • " + signal.symbol + " • automation is DISARMED.";
            AppPrefs.setUnivestStatus(getApplicationContext(), msg);
            DiagnosticsStore.runtime(getApplicationContext(), "SIGNAL_IGNORED_DISARMED", signal.symbol, msg);
            return;
        }

        PendingSignalStore.Item item = PendingSignalStore.enqueue(getApplicationContext(), signal, sbn.getPostTime());
        if (item == null) return;
        String mode = AppPrefs.isLiveTrading(getApplicationContext()) ? "LIVE" : "PAPER";
        String action = signal.type == UnivestParser.Type.ENTRY ? "₹20,000 entry" : signal.type == UnivestParser.Type.REENTRY ? "₹5,000 add" : "full CNC exit";
        AppPrefs.setUnivestStatus(getApplicationContext(), mode + " • UNIVEST " + signal.type + " DETECTED • " + signal.symbol + " • " + action + " queued durably.");
        DiagnosticsStore.runtime(getApplicationContext(), "SIGNAL_QUEUED", signal.symbol, "Durable queue id " + item.id + " • " + mode + " • " + action + ".");
        worker.execute(this::drainPending);
    }

    private void drainPending() {
        Context c = getApplicationContext();
        List<PendingSignalStore.Item> due = PendingSignalStore.due(c, System.currentTimeMillis(), 8);
        for (PendingSignalStore.Item item : due) {
            if (!AppPrefs.isUnivestEnabled(c)) {
                PendingSignalStore.remove(c, item.id);
                DiagnosticsStore.runtime(c, "QUEUED_SIGNAL_CANCELLED_DISARMED", item.symbol, "Queued signal removed because automation was disarmed before dispatch.");
                continue;
            }
            UnivestParser.Signal signal = UnivestParser.parse(item.rawText);
            if (signal == null) { PendingSignalStore.remove(c, item.id); DiagnosticsStore.error(c, "QUEUED_SIGNAL_REPARSE_FAILED", item.symbol, "Persisted signal no longer parsed; removed without order.", null); continue; }

            if (AppPrefs.isLiveTrading(c)) {
                GrowwClient.Result ready = GrowwClient.ensureLiveExecutionReady(c);
                if (!ready.success) {
                    long age = Math.max(0L, System.currentTimeMillis() - item.createdAt);
                    long maxAge = signal.type == UnivestParser.Type.EXIT ? 60L * 60L * 1000L : 15L * 60L * 1000L;
                    boolean transientFailure = ready.httpCode == 429 || ready.httpCode == 0 || ready.httpCode >= 500 || ready.unknown;
                    if (transientFailure && age < maxAge && item.attempts < 6) {
                        long delay = Math.min(300000L, 30000L << Math.min(4, item.attempts));
                        PendingSignalStore.reschedule(c, item, delay);
                        String msg = "LIVE signal retained for retry because broker readiness is temporarily unavailable • retry in ~" + (delay/1000L) + "s • " + ready.message;
                        DiagnosticsStore.runtime(c, "SIGNAL_RETRY_SCHEDULED", signal.symbol, msg);
                        AppPrefs.setUnivestStatus(c, msg);
                        continue;
                    }
                    PendingSignalStore.remove(c, item.id);
                    String msg = "LIVE signal not dispatched: " + ready.message + (transientFailure ? " • retry window exhausted" : " • configuration/authentication requires attention");
                    DiagnosticsStore.error(c, "SIGNAL_EXECUTION_READINESS_FAILED", signal.symbol, msg, null);
                    AppPrefs.setUnivestStatus(c, msg);
                    showLocalStatus("UNIVEST BLOCKED", msg, false);
                    continue;
                }
            }

            try {
                UnivestManager.handle(c, signal, item.postTime);
                PendingSignalStore.remove(c, item.id);
                showLocalStatus("UNIVEST " + signal.type, AppPrefs.getUnivestStatus(c), true);
            } catch (Throwable t) {
                PendingSignalStore.remove(c, item.id); // do not blind-retry after an unknown broker dispatch.
                DiagnosticsStore.error(c, "SIGNAL_HANDLER_EXCEPTION", signal.symbol,
                        "Signal handler threw after readiness passed. Removed from auto-retry to avoid duplicate broker orders.", t);
                showLocalStatus("UNIVEST ERROR", "Handler error for " + signal.symbol + ". Check exported diagnostics before retrying manually.", false);
            }
        }
    }

    @Override public void onDestroy() {
        worker.shutdown(); maintenance.shutdown(); super.onDestroy();
    }

    private String collectText(Notification n) {
        StringBuilder sb = new StringBuilder();
        append(sb, n.extras.getCharSequence(Notification.EXTRA_TITLE));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_TEXT));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        append(sb, n.extras.getCharSequence(Notification.EXTRA_SUB_TEXT));
        CharSequence[] lines = n.extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) for (CharSequence line : lines) append(sb, line);
        return sb.toString();
    }

    private void append(StringBuilder sb, CharSequence value) {
        if (value == null) return; String s = value.toString().trim(); if (s.isEmpty()) return;
        if (sb.indexOf(s) >= 0) return; if (sb.length() > 0) sb.append('\n'); sb.append(s);
    }

    private void showLocalStatus(String title, String text, boolean ok) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE); if (nm == null) return;
        String channelId = "univest_status";
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(channelId, "Univest AutoTrade status", NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channelId) : new Notification.Builder(this);
        b.setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(ok ? android.R.drawable.stat_notify_sync_noanim : android.R.drawable.stat_notify_error).setAutoCancel(true);
        nm.notify((int) (System.currentTimeMillis() & 0x7FFFFFFF), b.build());
    }

    private static String shortHash(String s) {
        try { MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] d = md.digest((s == null ? "" : s).getBytes(StandardCharsets.UTF_8)); StringBuilder out = new StringBuilder(); for (int i = 0; i < 8; i++) out.append(String.format(Locale.US, "%02x", d[i])); return out.toString(); }
        catch (Exception e) { return Integer.toHexString((s == null ? "" : s).hashCode()); }
    }
}
