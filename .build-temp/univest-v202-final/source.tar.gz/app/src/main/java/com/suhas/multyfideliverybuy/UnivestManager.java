package com.suhas.multyfideliverybuy;

import android.content.Context;

import java.util.List;
import java.util.Locale;

final class UnivestManager {
    static final int ENTRY_BUDGET = 20000;
    static final int REENTRY_BUDGET = 5000;
    static final int AVERAGE_BUDGET = 5000;
    static final int MAX_AVERAGE_LEVELS = 4;
    private static final double[] AVERAGE_DROPS = {0.02, 0.04, 0.06, 0.08};
    private static final long DUPLICATE_EXIT_GUARD_MS = 120000L;

    private UnivestManager() {}

    static void handle(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        if (signal == null) return;
        if (signal.type == UnivestParser.Type.ENTRY) handleEntry(context, signal, notificationPostTime);
        else if (signal.type == UnivestParser.Type.REENTRY) handleReentry(context, signal, notificationPostTime);
        else handleExit(context, signal, notificationPostTime);
    }

    static void handleEntry(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "ENTRY");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        if (!instrument.buyAllowed) { fail(context, "ENTRY_BUY_BLOCKED", symbol, "Groww instrument master marks buy_allowed=0.", null); return; }

        // PAPER is intentionally stateless. A paper test must never create a persistent ACTIVE campaign
        // that can later suppress a legitimate LIVE recommendation.
        if (!AppPrefs.isLiveTrading(context)) {
            String msg = "PAPER BUY • ₹20,000 CNC delivery simulation • no broker order sent";
            DiagnosticsStore.trade(context, "PAPER_BUY", symbol, msg, null);
            status(context, "PAPER MODE • UNIVEST ENTRY • " + symbol + " • simulated ₹20,000 CNC delivery buy. No Groww order sent and no LIVE state was reserved.");
            return;
        }

        // Broker is the source of truth for duplicate protection. Internal state alone is never enough.
        GrowwClient.PositionSnapshot holding = GrowwClient.getCncPosition(context, symbol);
        if (!holding.success) { fail(context, "ENTRY_HOLDING_CHECK_FAILED", symbol, holding.message, null); return; }
        if (holding.quantity > 0) {
            syncActiveStateFromBroker(context, symbol, instrument, holding, "New Univest entry ignored because broker already has CNC holding qty " + holding.quantity + ".");
            status(context, "UNIVEST ENTRY ALREADY HELD • " + symbol + " • broker CNC qty " + holding.quantity + " • no duplicate buy sent.");
            DiagnosticsStore.runtime(context, "ENTRY_DUPLICATE_BROKER_HOLDING", symbol, holding.message);
            return;
        }

        GrowwClient.Result openBuy = GrowwClient.hasOpenCncBuyOrderForSymbol(context, symbol);
        if (!openBuy.success) { fail(context, "ENTRY_OPEN_BUY_CHECK_FAILED", symbol, openBuy.message, null); return; }
        if (openBuy.httpCode == 409) {
            status(context, "UNIVEST ENTRY PENDING AT BROKER • " + symbol + " • existing open CNC BUY order found; no duplicate sent.");
            DiagnosticsStore.runtime(context, "ENTRY_DUPLICATE_OPEN_BUY", symbol, openBuy.message);
            return;
        }

        UnivestStateStore.State stale = UnivestStateStore.get(context, symbol);
        if (stale != null && !UnivestStateStore.EXITED.equals(stale.phase)) {
            UnivestStateStore.markBrokerFlat(context, symbol, "Stale internal campaign cleared because broker is flat and has no open CNC BUY.");
            DiagnosticsStore.runtime(context, "STALE_ACTIVE_STATE_CLEARED", symbol, "Broker reconciliation overrode stale state " + stale.phase + ".");
        }

        if (!UnivestStateStore.reserveNewEntry(context, symbol)) {
            UnivestStateStore.State existing = UnivestStateStore.get(context, symbol);
            String phase = existing == null ? "UNKNOWN" : existing.phase;
            status(context, "UNIVEST ENTRY CONCURRENT DUPLICATE IGNORED • " + symbol + " • state " + phase + ".");
            DiagnosticsStore.runtime(context, "ENTRY_CONCURRENT_DUPLICATE_IGNORED", symbol, "Another entry dispatch is already reserved in state " + phase + ".");
            return;
        }

        DiagnosticsStore.runtime(context, "ENTRY_ACCEPTED", symbol, "Eligible <=3 month Univest recommendation • fixed ₹20,000 CNC delivery budget.");
        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketBuy(context, symbol, ENTRY_BUDGET, ref("UVE", symbol));
        if (!r.submitted) {
            UnivestStateStore.releasePendingEntry(context, symbol, "Groww CNC BUY not submitted: " + r.message);
            fail(context, "ENTRY_NOT_SUBMITTED", symbol, r.message, null);
            DiagnosticsStore.trade(context, "BUY_FAILED", symbol, r.message, r);
            return;
        }

        UnivestStateStore.State state = new UnivestStateStore.State();
        state.symbol = symbol;
        state.phase = r.filled && r.filledQuantity > 0 ? UnivestStateStore.ACTIVE : UnivestStateStore.ERROR;
        state.anchorPrice = r.averagePrice;
        state.tickSize = instrument.tickSize;
        state.quantity = Math.max(0, r.filledQuantity);
        state.principal = Math.max(0, r.averagePrice) * Math.max(0, r.filledQuantity);
        state.estimatedBuyCharges = state.principal > 0 ? DeliveryNetTarget.buyCharges(state.principal) : 0;
        state.averageLevel = 0; state.reentryUsed = false; state.exitOrderId = r.orderId;
        state.brokerQtyAfterLastFill = Math.max(0, r.filledQuantity);
        state.lastAction = r.filled
                ? "Initial ₹20,000 CNC delivery BUY executed • qty " + r.filledQuantity + " • avg ₹" + money(r.averagePrice)
                : "CNC BUY submitted but fill not confirmed • order " + r.orderId;
        UnivestStateStore.put(context, state);

        DiagnosticsStore.trade(context, r.filled ? "BUY_EXECUTED" : "BUY_SUBMITTED_FILL_UNCONFIRMED", symbol, state.lastAction, r);
        if (r.filled && r.filledQuantity > 0 && r.averagePrice > 0) armNextAverage(context, state, instrument);
        long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
        status(context, "UNIVEST CNC BUY " + (r.filled ? "EXECUTED" : "SUBMITTED") + " • " + symbol
                + " • ₹20,000 budget" + (r.filled ? " • averaging ladder -2/-4/-6/-8% armed progressively" : "")
                + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
    }

    static void handleReentry(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "REENTRY");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        if (!instrument.buyAllowed) { fail(context, "REENTRY_BUY_BLOCKED", symbol, "Groww instrument master marks buy_allowed=0.", null); return; }

        if (!AppPrefs.isLiveTrading(context)) {
            String msg = "PAPER RE-ENTRY • +₹5,000 CNC delivery simulation • no broker order sent";
            DiagnosticsStore.trade(context, "PAPER_REENTRY", symbol, msg, null);
            status(context, "PAPER MODE • UNIVEST BACK-IN-RANGE • " + symbol + " • simulated +₹5,000 CNC add. No Groww order sent.");
            return;
        }

        GrowwClient.PositionSnapshot before = GrowwClient.getCncPosition(context, symbol);
        if (!before.success) { fail(context, "REENTRY_HOLDING_CHECK_FAILED", symbol, before.message, null); return; }
        if (before.quantity <= 0) {
            status(context, "UNIVEST BACK-IN-RANGE IGNORED • " + symbol + " • no CNC holding found.");
            DiagnosticsStore.runtime(context, "REENTRY_IGNORED_NO_HOLDING", symbol, before.message);
            return;
        }

        DiagnosticsStore.runtime(context, "REENTRY_ACCEPTED", symbol, "Back-in-range notification • fixed ₹5,000 CNC delivery add.");
        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketBuy(context, symbol, REENTRY_BUDGET, ref("UVR", symbol));
        if (!r.submitted) { fail(context, "REENTRY_NOT_SUBMITTED", symbol, r.message, null); DiagnosticsStore.trade(context, "REENTRY_BUY_FAILED", symbol, r.message, r); return; }

        UnivestStateStore.State state = UnivestStateStore.get(context, symbol);
        if (state == null) { state = new UnivestStateStore.State(); state.symbol = symbol; state.anchorPrice = before.netPrice; state.tickSize = instrument.tickSize; }
        state.phase = r.filled ? UnivestStateStore.ACTIVE : UnivestStateStore.ERROR;
        if (r.filled) {
            state.quantity = before.quantity + r.filledQuantity;
            state.principal = Math.max(0, state.principal) + Math.max(0, r.averagePrice) * Math.max(0, r.filledQuantity);
            if (!(state.anchorPrice > 0)) state.anchorPrice = before.netPrice > 0 ? before.netPrice : r.averagePrice;
            state.brokerQtyAfterLastFill = state.quantity;
            state.reentryUsed = true;
            state.lastAction = "₹5,000 back-in-range CNC add executed • qty " + r.filledQuantity + " • avg ₹" + money(r.averagePrice);
        } else state.lastAction = "₹5,000 CNC add submitted but fill not confirmed • order " + r.orderId;
        UnivestStateStore.put(context, state);
        if (r.filled && state.activeGttId.isEmpty()) armNextAverage(context, state, instrument);

        DiagnosticsStore.trade(context, r.filled ? "REENTRY_BUY_EXECUTED" : "REENTRY_FILL_UNCONFIRMED", symbol, state.lastAction, r);
        long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
        status(context, "UNIVEST ₹5,000 CNC RE-ENTRY " + (r.filled ? "EXECUTED" : "SUBMITTED") + " • " + symbol
                + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
    }

    static void handleExit(Context context, UnivestParser.Signal signal, long notificationPostTime) {
        InstrumentRepository.Instrument instrument = resolve(context, signal, "EXIT");
        if (instrument == null) return;
        String symbol = instrument.symbol;
        UnivestStateStore.State state = UnivestStateStore.get(context, symbol);
        if (state != null && UnivestStateStore.EXITING_OFFICIAL.equals(state.phase)
                && System.currentTimeMillis() - state.updatedAt < DUPLICATE_EXIT_GUARD_MS) {
            DiagnosticsStore.runtime(context, "EXIT_DUPLICATE_GUARDED", symbol, "Recent official exit is already being processed."); return;
        }

        if (!AppPrefs.isLiveTrading(context)) {
            DiagnosticsStore.trade(context, "PAPER_SELL", symbol, "Paper book-profit/exit simulated full CNC holding sell. No Groww order sent.", null);
            status(context, "PAPER MODE • UNIVEST BOOK PROFIT / EXIT • " + symbol + " • simulated full CNC holding sell. No Groww order sent.");
            return;
        }

        cancelTrackedOrders(context, state);
        GrowwClient.Result conflicts = GrowwClient.cancelOpenCncSellOrdersForSymbol(context, symbol);
        DiagnosticsStore.broker(context, "CANCEL_CONFLICTING_CNC_SELLS", symbol, conflicts.success || conflicts.unknown, conflicts.message);

        GrowwClient.PositionSnapshot holding = GrowwClient.getCncPosition(context, symbol);
        if (!holding.success) { fail(context, "EXIT_HOLDING_CHECK_FAILED", symbol, holding.message, null); return; }
        if (holding.quantity <= 0) {
            markExited(context, state, symbol, "Official Univest exit received; broker shows no CNC holding.");
            status(context, "UNIVEST BOOK PROFIT / EXIT • " + symbol + " • no holding found; nothing to sell.");
            DiagnosticsStore.runtime(context, "EXIT_NO_HOLDING", symbol, holding.message); return;
        }
        if (!instrument.sellAllowed) { fail(context, "EXIT_SELL_BLOCKED", symbol, "Groww instrument master marks sell_allowed=0.", null); return; }

        if (state == null) { state = new UnivestStateStore.State(); state.symbol = symbol; }
        state.phase = UnivestStateStore.EXITING_OFFICIAL; state.exitRequestedQty = holding.quantity;
        state.lastAction = "Official Univest book-profit/exit • CNC MARKET SELL requested for full broker holding qty " + holding.quantity;
        UnivestStateStore.put(context, state);

        GrowwClient.ExecutionResult r = GrowwClient.placeUnivestCncMarketSell(context, symbol, holding.quantity, ref("UVX", symbol));
        DiagnosticsStore.trade(context, r.submitted ? "SELL_SUBMITTED" : "SELL_FAILED", symbol, state.lastAction, r);
        if (!r.submitted) { fail(context, "EXIT_NOT_SUBMITTED", symbol, r.message, null); return; }

        GrowwClient.PositionSnapshot after = GrowwClient.getCncPosition(context, symbol);
        if (r.filled || (after.success && after.quantity == 0)) {
            markExited(context, state, symbol, "Official Univest exit executed • sold full CNC holding.");
            long age = r.dispatchAtMillis > 0 && notificationPostTime > 0 ? Math.max(0, r.dispatchAtMillis - notificationPostTime) : -1;
            status(context, "UNIVEST CNC SELL EXECUTED • " + symbol + " • qty " + holding.quantity
                    + (age >= 0 ? " • source age " + age + " ms" : "") + " • " + r.message);
        } else {
            state.phase = UnivestStateStore.EXITING_OFFICIAL; state.exitOrderId = r.orderId;
            state.lastAction = "CNC SELL accepted; fill/position-zero not yet confirmed. " + r.message;
            UnivestStateStore.put(context, state); status(context, "UNIVEST SELL ACCEPTED — VERIFYING • " + symbol + " • " + r.message);
        }
    }

    static void migrateLegacyRules(Context context) {
        if (AppPrefs.isUnivestV2Migrated(context)) return;
        boolean allClean = true;
        for (UnivestStateStore.State state : UnivestStateStore.all(context)) {
            if (state.activeGttId != null && !state.activeGttId.isEmpty()) {
                GrowwClient.Result r = GrowwClient.cancelCashGtt(context, state.activeGttId);
                DiagnosticsStore.broker(context, "CANCEL_LEGACY_AVERAGE_GTT", state.symbol, r.success || r.unknown, r.message);
                if (r.success) { state.activeGttId = ""; state.activeGttKind = ""; state.activeGttQty = 0; state.activeGttPrice = 0; } else allClean = false;
            }
            if (state.protectiveStopGttId != null && !state.protectiveStopGttId.isEmpty()) {
                GrowwClient.Result r = GrowwClient.cancelCashGtt(context, state.protectiveStopGttId);
                DiagnosticsStore.broker(context, "CANCEL_LEGACY_STOP_GTT", state.symbol, r.success || r.unknown, r.message);
                if (r.success) { state.protectiveStopGttId = ""; state.protectiveStopPrice = 0; state.protectiveStopQty = 0; } else allClean = false;
            }
            UnivestStateStore.put(context, state);
        }
        if (allClean) { AppPrefs.setUnivestV2Migrated(context, true); DiagnosticsStore.runtime(context, "V2_RULE_MIGRATION_COMPLETE", "", "Legacy stop/profit GTT rules removed; notification-driven exits preserved."); }
    }

    static void migrateV202(Context context) {
        if (AppPrefs.isUnivestV202Migrated(context)) return;
        int cleaned = UnivestStateStore.clearLegacyPaperStates(context);
        AppPrefs.setUnivestV202Migrated(context, true);
        DiagnosticsStore.runtime(context, "V202_MIGRATION_COMPLETE", "", "Cleared " + cleaned + " stale PAPER campaign state(s). Broker-reconciled duplicate checks + four-level -2/-4/-6/-8% averaging enabled.");
    }

    static void reconcileAll(Context context) {
        migrateLegacyRules(context); migrateV202(context); DiagnosticsStore.rotateIfNeeded(context);
        if (!AppPrefs.isLiveTrading(context) || !AppPrefs.isUnivestEnabled(context)) return;

        // Averaging is a multi-day campaign. Groww access tokens roll into a new window each day,
        // so relying on yesterday's manual TEST CONNECTION would silently stall the next -2% step.
        // Refresh readiness automatically, but at most once every five minutes when unavailable so
        // a broker outage/rate-limit cannot create an authentication storm.
        if (!AppPrefs.isReadyForBuy(context)) {
            if (!AppPrefs.claimRecent(context, "averaging_readiness_refresh", 5L * 60L * 1000L)) return;
            GrowwClient.Result ready = GrowwClient.ensureLiveExecutionReady(context);
            DiagnosticsStore.broker(context, "AVERAGING_READINESS_REFRESH", "", ready.success, ready.message);
            if (!ready.success) return;
        }
        reconcileAveraging(context);
    }

    static void reconcileAveraging(Context context) {
        if (!AppPrefs.isLiveTrading(context) || !AppPrefs.isUnivestEnabled(context) || !AppPrefs.isReadyForBuy(context)) return;
        for (UnivestStateStore.State state : UnivestStateStore.all(context)) {
            if (state == null || state.symbol.isEmpty() || UnivestStateStore.EXITED.equals(state.phase) || UnivestStateStore.EXITING_OFFICIAL.equals(state.phase)) continue;
            GrowwClient.PositionSnapshot p = GrowwClient.getCncPosition(context, state.symbol);
            if (!p.success) continue;
            if (p.quantity <= 0) {
                if (state.activeGttId != null && !state.activeGttId.isEmpty()) {
                    GrowwClient.Result cancel = GrowwClient.cancelCashGtt(context, state.activeGttId);
                    DiagnosticsStore.broker(context, "AVERAGE_GTT_CANCEL_FLAT", state.symbol, cancel.success || cancel.unknown, cancel.message);
                }
                UnivestStateStore.markBrokerFlat(context, state.symbol, "Broker became flat; averaging cancelled to prevent unintended re-entry.");
                continue;
            }
            if (!(state.anchorPrice > 0) && p.netPrice > 0) state.anchorPrice = p.netPrice;
            if (state.brokerQtyAfterLastFill <= 0) state.brokerQtyAfterLastFill = p.quantity;

            if (state.activeGttId != null && !state.activeGttId.isEmpty() && p.quantity > state.brokerQtyAfterLastFill) {
                int added = p.quantity - state.brokerQtyAfterLastFill;
                state.averageLevel = Math.min(MAX_AVERAGE_LEVELS, state.averageLevel + 1);
                state.quantity = p.quantity; if (p.netPrice > 0) state.principal = p.netPrice * p.quantity;
                state.brokerQtyAfterLastFill = p.quantity; state.activeGttId = ""; state.activeGttKind = ""; state.activeGttQty = 0; state.activeGttPrice = 0.0;
                state.phase = UnivestStateStore.ACTIVE; state.lastAction = "Downward average level " + state.averageLevel + " reconciled from broker • added qty " + added + ".";
                UnivestStateStore.put(context, state);
                DiagnosticsStore.runtime(context, "AVERAGE_FILL_RECONCILED", state.symbol, state.lastAction);
            } else if (state.activeGttId != null && !state.activeGttId.isEmpty()) {
                GrowwClient.GttStatusResult g = GrowwClient.getCashGttStatus(context, state.activeGttId);
                String st = g.status == null ? "" : g.status.toUpperCase(Locale.US);
                if (g.success && (st.contains("CANCEL") || st.contains("REJECT") || st.contains("FAIL") || st.contains("EXPIRE"))) {
                    DiagnosticsStore.runtime(context, "AVERAGE_GTT_TERMINAL", state.symbol, "Average GTT " + state.activeGttId + " status " + st + "; same level will be re-armed.");
                    state.activeGttId = ""; state.activeGttKind = ""; state.activeGttQty = 0; state.activeGttPrice = 0.0; UnivestStateStore.put(context, state);
                }
            }
            if ((state.activeGttId == null || state.activeGttId.isEmpty()) && state.averageLevel < MAX_AVERAGE_LEVELS) {
                InstrumentRepository.Instrument i = InstrumentRepository.resolve(InstrumentRepository.load(context), state.symbol);
                if (i != null) armNextAverage(context, state, i);
            } else UnivestStateStore.put(context, state);
        }
    }

    static void pauseAveraging(Context context, String reason) {
        for (UnivestStateStore.State state : UnivestStateStore.all(context)) {
            if (state.activeGttId == null || state.activeGttId.isEmpty()) continue;
            GrowwClient.Result r = GrowwClient.cancelCashGtt(context, state.activeGttId);
            DiagnosticsStore.broker(context, "AVERAGING_PAUSED", state.symbol, r.success || r.unknown, (reason == null ? "" : reason + " • ") + r.message);
            if (r.success) { state.activeGttId=""; state.activeGttKind=""; state.activeGttQty=0; state.activeGttPrice=0.0; UnivestStateStore.put(context,state); }
        }
    }

    private static void armNextAverage(Context context, UnivestStateStore.State state, InstrumentRepository.Instrument instrument) {
        if (state == null || instrument == null || !AppPrefs.isLiveTrading(context) || !AppPrefs.isUnivestEnabled(context)) return;
        if (!(state.anchorPrice > 0) || state.averageLevel >= MAX_AVERAGE_LEVELS) return;
        if (state.activeGttId != null && !state.activeGttId.isEmpty()) return;
        double trigger = averageTriggerPrice(state.anchorPrice, instrument.tickSize, state.averageLevel);
        int qty = averageQuantity(trigger);
        if (!(trigger > 0) || qty < 1) { DiagnosticsStore.error(context, "AVERAGE_GTT_SIZING_FAILED", state.symbol, "Cannot size ₹5,000 average at trigger ₹" + money(trigger), null); return; }
        int levelNumber = state.averageLevel + 1;
        GrowwClient.GttResult g = GrowwClient.createUnivestCncBuyGtt(context, state.symbol, qty, trigger, ref("UVA" + levelNumber, state.symbol));
        DiagnosticsStore.broker(context, "AVERAGE_GTT_CREATE_L" + levelNumber, state.symbol, g.success || g.unknown,
                "₹5,000 downward average • level " + levelNumber + " • drop " + (levelNumber * 2) + "% • qty " + qty + " • trigger ₹" + money(trigger) + " • " + g.message);
        if (g.success && g.smartOrderId != null && !g.smartOrderId.isEmpty()) {
            state.activeGttId = g.smartOrderId; state.activeGttKind = "AVERAGE_L" + levelNumber; state.activeGttQty = qty; state.activeGttPrice = trigger;
            state.brokerQtyAfterLastFill = Math.max(state.brokerQtyAfterLastFill, state.quantity); state.phase = UnivestStateStore.ACTIVE;
            state.lastAction = "Averaging GTT armed: ₹5,000 at -" + (levelNumber * 2) + "% from original entry • trigger ₹" + money(trigger) + " • qty " + qty;
            UnivestStateStore.put(context, state);
        }
    }

    static double averageTriggerPrice(double anchor, double tick, int completedLevels) {
        if (!(anchor > 0) || completedLevels < 0 || completedLevels >= AVERAGE_DROPS.length) return 0.0;
        double t = tick > 0 ? tick : 0.05; double raw = anchor * (1.0 - AVERAGE_DROPS[completedLevels]);
        double rounded = Math.floor((raw / t) + 1e-9) * t; return Math.max(t, Math.round(rounded * 10000.0) / 10000.0);
    }

    static int averageQuantity(double triggerPrice) { return triggerPrice > 0 ? (int)Math.floor(AVERAGE_BUDGET / triggerPrice) : 0; }

    private static void syncActiveStateFromBroker(Context context, String symbol, InstrumentRepository.Instrument instrument, GrowwClient.PositionSnapshot p, String action) {
        UnivestStateStore.State s = UnivestStateStore.get(context, symbol); if (s == null) { s = new UnivestStateStore.State(); s.symbol = symbol; }
        s.phase = UnivestStateStore.ACTIVE; s.quantity = p.quantity; s.brokerQtyAfterLastFill = p.quantity;
        if (!(s.anchorPrice > 0) && p.netPrice > 0) s.anchorPrice = p.netPrice; if (instrument != null) s.tickSize = instrument.tickSize;
        if (p.netPrice > 0) s.principal = p.netPrice * p.quantity; s.lastAction = action; UnivestStateStore.put(context, s);
    }

    private static InstrumentRepository.Instrument resolve(Context context, UnivestParser.Signal signal, String action) {
        try { InstrumentRepository.refreshIfStale(context); } catch (Throwable ignored) {}
        List<InstrumentRepository.Instrument> instruments = InstrumentRepository.load(context);
        InstrumentRepository.Instrument i = InstrumentRepository.resolve(instruments, signal.symbol);
        if (i != null) {
            if (!i.symbol.equalsIgnoreCase(signal.symbol)) DiagnosticsStore.runtime(context, "SYMBOL_MAPPED", i.symbol, "Univest stock text '" + signal.symbol + "' mapped to NSE symbol " + i.symbol + " (" + i.name + ").");
            return i;
        }
        List<String> suggestions = InstrumentRepository.suggestions(instruments, signal.symbol, 5);
        String msg = action + " symbol mapping failed for Univest stock text '" + signal.symbol + "'. Candidates: " + suggestions;
        fail(context, "SYMBOL_MAPPING_FAILED", signal.symbol, msg, null); return null;
    }

    private static void cancelTrackedOrders(Context context, UnivestStateStore.State s) {
        if (s == null) return;
        if (s.activeGttId != null && !s.activeGttId.isEmpty()) {
            GrowwClient.Result r = GrowwClient.cancelCashGtt(context, s.activeGttId);
            DiagnosticsStore.broker(context, "CANCEL_AVERAGE_GTT_BEFORE_EXIT", s.symbol, r.success || r.unknown, r.message);
            if (r.success) { s.activeGttId = ""; s.activeGttKind=""; s.activeGttQty=0; s.activeGttPrice=0.0; }
        }
        if (s.protectiveStopGttId != null && !s.protectiveStopGttId.isEmpty()) {
            GrowwClient.Result r = GrowwClient.cancelCashGtt(context, s.protectiveStopGttId);
            DiagnosticsStore.broker(context, "CANCEL_LEGACY_STOP_BEFORE_EXIT", s.symbol, r.success || r.unknown, r.message);
            if (r.success) s.protectiveStopGttId = "";
        }
        UnivestStateStore.put(context, s);
    }

    private static void markExited(Context c, UnivestStateStore.State s, String symbol, String message) {
        if (s == null) { s = new UnivestStateStore.State(); s.symbol = symbol; }
        s.phase = UnivestStateStore.EXITED; s.quantity = 0; s.principal = 0; s.estimatedBuyCharges = 0; s.exitRequestedQty = 0;
        s.activeGttId = ""; s.activeGttKind=""; s.activeGttQty=0; s.activeGttPrice=0.0; s.protectiveStopGttId = ""; s.lastAction = message; UnivestStateStore.put(c, s);
    }

    private static void fail(Context c, String event, String symbol, String message, Throwable t) { DiagnosticsStore.error(c, event, symbol, message, t); status(c, "UNIVEST ERROR • " + symbol + " • " + message); }
    private static void status(Context c, String text) { AppPrefs.setUnivestStatus(c, text); DiagnosticsStore.runtime(c, "STATUS", "", text); }
    private static String ref(String prefix, String symbol) { String s=(prefix+Long.toString(System.currentTimeMillis(),36)+symbol).toUpperCase(Locale.US).replaceAll("[^A-Z0-9]",""); if(s.length()>20)s=s.substring(0,20); while(s.length()<8)s+="0"; return s; }
    private static String money(double v) { return String.format(Locale.US, "%.2f", v); }
}
