package com.suhas.multyfideliverybuy;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

final class PendingSignalStore {
    private static final String FILE = "univest_pending_signals";
    private static final String KEY = "items";

    static final class Item {
        String id = "";
        String rawText = "";
        String type = "";
        String symbol = "";
        long postTime = 0L;
        long createdAt = 0L;
        long nextAttemptAt = 0L;
        int attempts = 0;

        JSONObject toJson() {
            JSONObject j = new JSONObject();
            try {
                j.put("id", id); j.put("rawText", rawText); j.put("type", type); j.put("symbol", symbol);
                j.put("postTime", postTime); j.put("createdAt", createdAt); j.put("nextAttemptAt", nextAttemptAt); j.put("attempts", attempts);
            } catch (Exception ignored) {}
            return j;
        }

        static Item fromJson(JSONObject j) {
            Item i = new Item();
            i.id = j.optString("id", ""); i.rawText = j.optString("rawText", ""); i.type = j.optString("type", ""); i.symbol = j.optString("symbol", "");
            i.postTime = j.optLong("postTime", 0L); i.createdAt = j.optLong("createdAt", 0L); i.nextAttemptAt = j.optLong("nextAttemptAt", 0L); i.attempts = j.optInt("attempts", 0);
            return i;
        }
    }

    private PendingSignalStore() {}
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(FILE, Context.MODE_PRIVATE); }

    static synchronized Item enqueue(Context c, UnivestParser.Signal signal, long postTime) {
        if (signal == null) return null;
        long now = System.currentTimeMillis();
        String id = idFor(signal);
        List<Item> list = all(c);
        for (Item x : list) if (x.id.equals(id)) return x;
        Item i = new Item(); i.id=id; i.rawText=signal.rawText; i.type=signal.type.name(); i.symbol=signal.symbol; i.postTime=postTime; i.createdAt=now; i.nextAttemptAt=now;
        list.add(i); save(c,list); return i;
    }

    static synchronized List<Item> due(Context c, long now, int max) {
        List<Item> list = all(c); List<Item> due = new ArrayList<>();
        list.sort(Comparator.comparingInt((Item i) -> "EXIT".equals(i.type) ? 0 : 1).thenComparingLong(i -> i.createdAt));
        for (Item i : list) { if (i.nextAttemptAt <= now) { due.add(i); if (due.size() >= max) break; } }
        return due;
    }

    static synchronized void remove(Context c, String id) {
        List<Item> list = all(c); list.removeIf(x -> x.id.equals(id)); save(c,list);
    }

    static synchronized void reschedule(Context c, Item item, long delayMs) {
        List<Item> list = all(c);
        for (Item x : list) if (x.id.equals(item.id)) { x.attempts++; x.nextAttemptAt = System.currentTimeMillis()+Math.max(1000L,delayMs); break; }
        save(c,list);
    }

    static synchronized int count(Context c) { return all(c).size(); }

    static synchronized List<Item> all(Context c) {
        List<Item> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(p(c).getString(KEY,"[]")); for(int n=0;n<a.length();n++){ JSONObject j=a.optJSONObject(n); if(j!=null){ Item i=Item.fromJson(j); if(!i.id.isEmpty()) out.add(i); } } } catch(Exception ignored) {}
        return out;
    }

    private static void save(Context c, List<Item> list) { JSONArray a=new JSONArray(); for(Item i:list)a.put(i.toJson()); p(c).edit().putString(KEY,a.toString()).apply(); }

    private static String idFor(UnivestParser.Signal s) {
        String normalized=(s.type.name()+"|"+s.symbol+"|"+(s.rawText==null?"":s.rawText.replaceAll("\\s+"," ").trim())).toUpperCase(Locale.US);
        try { MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] d=md.digest(normalized.getBytes(StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); for(int i=0;i<12;i++) b.append(String.format(Locale.US,"%02x",d[i])); return b.toString(); }
        catch(Exception e){ return Integer.toHexString(normalized.hashCode()); }
    }
}
