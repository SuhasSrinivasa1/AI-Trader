package com.suhas.multyfideliverybuy;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Locale;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

final class GrowwClient {
    private static final String TOKEN_URL = "https://api.groww.in/v1/token/api/access";
    private static final String ORDER_URL = "https://api.groww.in/v1/order/create";
    private static final String ORDER_DETAIL_URL = "https://api.groww.in/v1/order/detail/";
    private static final String ORDER_LIST_URL = "https://api.groww.in/v1/order/list";
    private static final String ORDER_CANCEL_URL = "https://api.groww.in/v1/order/cancel";
    private static final String GTT_URL = "https://api.groww.in/v1/order-advance/create";
    private static final String LTP_URL = "https://api.groww.in/v1/live-data/ltp";
    private static final String USER_URL = "https://api.groww.in/v1/user/detail";
    private static final String GTT_STATUS_URL = "https://api.groww.in/v1/order-advance/status/CASH/GTT/internal/";
    private static final String GTT_CANCEL_URL = "https://api.groww.in/v1/order-advance/cancel/CASH/GTT/";
    private static final String SMART_MODIFY_URL = "https://api.groww.in/v1/order-advance/modify/";
    private static final String POSITION_SYMBOL_URL = "https://api.groww.in/v1/positions/trading-symbol";
    private static final String HOLDINGS_URL = "https://api.groww.in/v1/holdings/user";

    static final class Result {
        final boolean success;
        final boolean unknown;
        final int httpCode;
        final String message;
        Result(boolean success, boolean unknown, int httpCode, String message) {
            this.success = success;
            this.unknown = unknown;
            this.httpCode = httpCode;
            this.message = message;
        }
    }

    static final class ManualResult {
        final boolean entrySubmitted;
        final boolean targetSubmitted;
        final boolean unknown;
        final String message;
        ManualResult(boolean entrySubmitted, boolean targetSubmitted, boolean unknown, String message) {
            this.entrySubmitted = entrySubmitted;
            this.targetSubmitted = targetSubmitted;
            this.unknown = unknown;
            this.message = message;
        }
    }

    static final class MultyfiEntryResult {
        final boolean entrySubmitted;
        final boolean gttSubmitted;
        final boolean unknown;
        final String orderId;
        final String smartOrderId;
        final int filledQuantity;
        final double averagePrice;
        final double targetPrice;
        final double breakEvenPrice;
        final double tickSize;
        final String message;
        MultyfiEntryResult(boolean entrySubmitted, boolean gttSubmitted, boolean unknown, String orderId,
                           String smartOrderId, int filledQuantity, double averagePrice, double targetPrice,
                           double breakEvenPrice, double tickSize, String message) {
            this.entrySubmitted = entrySubmitted; this.gttSubmitted = gttSubmitted; this.unknown = unknown;
            this.orderId = orderId; this.smartOrderId = smartOrderId; this.filledQuantity = filledQuantity;
            this.averagePrice = averagePrice; this.targetPrice = targetPrice; this.breakEvenPrice = breakEvenPrice;
            this.tickSize = tickSize; this.message = message;
        }
    }

    static final class ShortOcoResult {
        final boolean shortSubmitted;
        final boolean ocoSubmitted;
        final boolean unknown;
        final int quantity;
        final double averageShortPrice;
        final double targetPrice;
        final double stopPrice;
        final String smartOrderId;
        final String message;
        ShortOcoResult(boolean shortSubmitted, boolean ocoSubmitted, boolean unknown, int quantity,
                       double averageShortPrice, double targetPrice, double stopPrice, String smartOrderId, String message) {
            this.shortSubmitted = shortSubmitted; this.ocoSubmitted = ocoSubmitted; this.unknown = unknown;
            this.quantity = quantity; this.averageShortPrice = averageShortPrice; this.targetPrice = targetPrice;
            this.stopPrice = stopPrice; this.smartOrderId = smartOrderId; this.message = message;
        }
    }

    static final class ExecutionResult {
        final boolean submitted;
        final boolean filled;
        final boolean unknown;
        final String orderId;
        final int requestedQuantity;
        final int filledQuantity;
        final double averagePrice;
        final double sizingLtp;
        final long dispatchAtMillis;
        final String message;
        ExecutionResult(boolean submitted, boolean filled, boolean unknown, String orderId, int requestedQuantity,
                        int filledQuantity, double averagePrice, double sizingLtp, long dispatchAtMillis, String message) {
            this.submitted = submitted; this.filled = filled; this.unknown = unknown; this.orderId = orderId;
            this.requestedQuantity = requestedQuantity; this.filledQuantity = filledQuantity;
            this.averagePrice = averagePrice; this.sizingLtp = sizingLtp; this.dispatchAtMillis = dispatchAtMillis;
            this.message = message;
        }
    }

    static final class GttResult {
        final boolean success;
        final boolean unknown;
        final String smartOrderId;
        final String message;
        GttResult(boolean success, boolean unknown, String smartOrderId, String message) {
            this.success = success; this.unknown = unknown; this.smartOrderId = smartOrderId; this.message = message;
        }
    }

    static final class GttStatusResult {
        final boolean success;
        final String status;
        final String triggeredAt;
        final String message;
        GttStatusResult(boolean success, String status, String triggeredAt, String message) {
            this.success = success; this.status = status; this.triggeredAt = triggeredAt; this.message = message;
        }
    }

    static final class PositionSnapshot {
        final boolean success;
        final int quantity;
        final double netPrice;
        final String message;
        PositionSnapshot(boolean success, int quantity, double netPrice, String message) {
            this.success = success; this.quantity = quantity; this.netPrice = netPrice; this.message = message;
        }
    }

    private static final class OrderSubmit {
        final boolean success;
        final boolean unknown;
        final int code;
        final String orderId;
        final String message;
        OrderSubmit(boolean success, boolean unknown, int code, String orderId, String message) {
            this.success = success;
            this.unknown = unknown;
            this.code = code;
            this.orderId = orderId;
            this.message = message;
        }
    }

    private static final class Fill {
        final boolean confirmed;
        final int quantity;
        final double averagePrice;
        final String status;
        Fill(boolean confirmed, int quantity, double averagePrice, String status) {
            this.confirmed = confirmed;
            this.quantity = quantity;
            this.averagePrice = averagePrice;
            this.status = status;
        }
    }

    private GrowwClient() {}

    static Result authenticate(Context context) {
        long now = System.currentTimeMillis();
        long backoffUntil = AppPrefs.getAuthBackoffUntil(context);
        if (backoffUntil > now) {
            long seconds = Math.max(1L, (backoffUntil - now + 999L) / 1000L);
            return new Result(false, false, 429, "Groww authentication cooldown active after rate limiting. Retry in about " + seconds + " seconds.");
        }
        // Groww TOTP flow: Authorization bearer is the long-lived TOTP token, not the daily access token.
        // The request body contains a locally generated 6-digit TOTP. Groww documents X-API-VERSION: 1.0
        // as a mandatory header for API requests, including access-token generation.
        String totpToken = AppPrefs.getApiKey(context);
        String secret = AppPrefs.getTotpSecret(context);
        if (totpToken.isEmpty() || secret.isEmpty()) {
            return new Result(false, false, 0, "Groww TOTP token and TOTP Base32 secret are required.");
        }
        try {
            String normalizedSecret = normalizeTotpSecret(secret);
            if (normalizedSecret.length() < 8) {
                return new Result(false, false, 0, "TOTP secret is too short or invalid. Paste the Base32 secret paired with your Groww TOTP token.");
            }
            String totp = generateTotp(normalizedSecret, System.currentTimeMillis());
            if (!totp.matches("\\d{6}")) {
                return new Result(false, false, 0, "Local TOTP generation failed validation.");
            }
            DiagnosticsStore.broker(context, "GROWW_TOTP_REQUEST", "", true,
                    "TOTP request prepared • token present • Base32 secret validated • 6-digit code generated locally • X-API-VERSION 1.0 enabled.");

            JSONObject body = new JSONObject();
            body.put("key_type", "totp");
            body.put("totp", totp);
            // v2.0.1 fix: v2.0.0 omitted X-API-VERSION on this token endpoint call.
            HttpResponse r = post(TOKEN_URL, totpToken, body.toString(), true);
            if (r.code >= 200 && r.code < 300) {
                JSONObject json = new JSONObject(r.body);
                String token = json.optString("token", "");
                if (token.isEmpty()) {
                    JSONObject payload = json.optJSONObject("payload");
                    if (payload != null) token = payload.optString("token", "");
                }
                if (!token.isEmpty()) {
                    AppPrefs.setAccessToken(context, token);
                    AppPrefs.clearAuthBackoff(context);
                    DiagnosticsStore.broker(context, "GROWW_TOTP_TOKEN_EXCHANGE", "", true,
                            "Groww TOTP authentication accepted. Daily access token cached securely.");
                    return new Result(true, false, r.code, "Groww TOTP authentication successful. Access token cached.");
                }
                DiagnosticsStore.broker(context, "GROWW_TOTP_TOKEN_EXCHANGE", "", false,
                        "Groww returned HTTP " + r.code + " but no access token was present.");
                return new Result(false, false, r.code, "Groww authentication response did not contain an access token.");
            }
            if (r.code == 429) AppPrefs.setAuthBackoffUntil(context, System.currentTimeMillis() + 90000L);
            String detail = "Groww TOTP authentication rejected (HTTP " + r.code + "): " + shortText(r.body)
                    + (r.code == 429 ? " • Automatic 90-second cooldown started." : "")
                    + " • Request used TOTP token + generated 6-digit TOTP + X-API-VERSION 1.0.";
            DiagnosticsStore.broker(context, "GROWW_TOTP_TOKEN_EXCHANGE", "", false, detail);
            return new Result(false, false, r.code, detail);
        } catch (Exception e) {
            String detail = "Groww TOTP authentication failed before token exchange: " + safeMessage(e);
            DiagnosticsStore.error(context, "GROWW_TOTP_AUTH_EXCEPTION", "", detail, e);
            return new Result(false, false, 0, detail);
        }
    }

    static Result refreshAndTestAuthentication(Context context) {
        Result auth = authenticate(context);
        if (!auth.success) {
            AppPrefs.setAuthTest(context, false, auth.message);
            return auth;
        }
        try {
            HttpResponse r = get(USER_URL, AppPrefs.getAccessToken(context), true);
            if (r.code >= 200 && r.code < 300) {
                JSONObject json = new JSONObject(r.body);
                boolean apiSuccess = "SUCCESS".equalsIgnoreCase(json.optString("status", "SUCCESS"));
                JSONObject payload = json.optJSONObject("payload");
                boolean nseEnabled = payload != null && payload.optBoolean("nse_enabled", false);
                boolean cashEnabled = false;
                if (payload != null && payload.optJSONArray("active_segments") != null) {
                    for (int i = 0; i < payload.optJSONArray("active_segments").length(); i++) {
                        if ("CASH".equalsIgnoreCase(payload.optJSONArray("active_segments").optString(i))) {
                            cashEnabled = true; break;
                        }
                    }
                }
                if (apiSuccess && nseEnabled && cashEnabled) {
                    String msg = "Groww AUTHENTICATED — access token refreshed; NSE CASH profile test passed.";
                    AppPrefs.setAuthTest(context, true, msg);
                    return new Result(true, false, r.code, msg);
                }
                String msg = "Groww token works, but NSE CASH is not enabled in the user profile.";
                AppPrefs.setAuthTest(context, false, msg);
                return new Result(false, false, r.code, msg);
            }
            String msg = "Groww authentication test failed (HTTP " + r.code + "): " + shortText(r.body);
            AppPrefs.setAuthTest(context, false, msg);
            return new Result(false, false, r.code, msg);
        } catch (Exception e) {
            String msg = "Groww authentication test failed: " + safeMessage(e);
            AppPrefs.setAuthTest(context, false, msg);
            return new Result(false, false, 0, msg);
        }
    }

    static Result ensureLiveExecutionReady(Context context) {
        if (!AppPrefs.hasLiveConfiguration(context)) return new Result(false, false, 0, "Groww TOTP token, Base32 secret and whitelisted static IP must be configured.");
        NetworkCheck.Result ip = NetworkCheck.detectAndCompare(context);
        DiagnosticsStore.broker(context, "AUTO_STATIC_IP_CHECK", "", ip.match, ip.message);
        if (!ip.match) return new Result(false, true, 0, "Static IP readiness failed: " + ip.message);
        if (AppPrefs.isAuthTestFresh(context) && !AppPrefs.getAccessToken(context).isEmpty()) return new Result(true, false, 200, "Cached Groww access token is fresh for the current token window.");
        Result auth = refreshAndTestAuthentication(context);
        DiagnosticsStore.broker(context, "AUTO_GROWW_AUTH_REFRESH", "", auth.success, auth.message);
        return auth;
    }

    static Result placeDeliveryMarketBuy(Context context, String symbol, int quantity, String referenceId) {
        OrderSubmit s = submitMarketOrder(context, symbol, quantity, "CNC", "BUY", referenceId);
        return new Result(s.success, s.unknown, s.code, s.message);
    }


    /** Univest equity fast path: one LTP read only for ₹20k quantity sizing, then immediate CNC MARKET BUY. */
    static ExecutionResult placeUnivestCncMarketBuy(Context context, String symbol, int budget, String referenceId) {
        try {
            double ltp = getLtp(context, symbol);
            if (!(ltp > 0)) return new ExecutionResult(false, false, false, "", 0, 0, 0, 0, 0,
                    "No valid Groww LTP for " + symbol + "; no Univest order submitted.");
            int quantity = (int) Math.floor(budget / ltp);
            if (quantity < 1) return new ExecutionResult(false, false, false, "", 0, 0, 0, ltp, 0,
                    symbol + " LTP ₹" + money(ltp) + " is above the ₹" + inr(budget) + " Univest budget.");
            long dispatch = System.currentTimeMillis();
            OrderSubmit entry = submitMarketOrder(context, symbol, quantity, "CNC", "BUY", referenceId);
            if (!entry.success) return new ExecutionResult(false, false, entry.unknown, entry.orderId, quantity, 0, 0, ltp, dispatch, entry.message);
            if (entry.orderId.isEmpty()) return new ExecutionResult(true, false, false, "", quantity, 0, 0, ltp, dispatch,
                    "CNC MARKET BUY accepted, but Groww returned no order ID. Verify fill manually.");
            Fill fill = awaitExecution(context, entry.orderId, quantity);
            return new ExecutionResult(true, fill.quantity > 0 && fill.averagePrice > 0, false, entry.orderId, quantity,
                    fill.quantity, fill.averagePrice, ltp, dispatch,
                    fill.quantity > 0 && fill.averagePrice > 0
                            ? "CNC MARKET BUY executed • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                            : "CNC MARKET BUY accepted • order " + entry.orderId + " • fill not confirmed in time.");
        } catch (SocketTimeoutException e) {
            return new ExecutionResult(false, false, true, "", 0, 0, 0, 0, 0,
                    "Univest entry status unknown after network timeout. Check Groww before any manual retry.");
        } catch (Exception e) {
            return new ExecutionResult(false, false, true, "", 0, 0, 0, 0, 0,
                    "Univest entry failed/unknown: " + safeMessage(e));
        }
    }

    static ExecutionResult placeUnivestCncMarketSell(Context context, String symbol, int quantity, String referenceId) {
        if (quantity <= 0) return new ExecutionResult(false, false, false, "", 0, 0, 0, 0, 0, "Sell quantity is zero.");
        long dispatch = System.currentTimeMillis();
        OrderSubmit sell = submitMarketOrder(context, symbol, quantity, "CNC", "SELL", referenceId);
        if (!sell.success) return new ExecutionResult(false, false, sell.unknown, sell.orderId, quantity, 0, 0, 0, dispatch, sell.message);
        if (sell.orderId.isEmpty()) return new ExecutionResult(true, false, false, "", quantity, 0, 0, 0, dispatch,
                "CNC MARKET SELL accepted, but Groww returned no order ID. Verify execution manually.");
        try {
            Fill fill = awaitExecution(context, sell.orderId, quantity);
            return new ExecutionResult(true, fill.quantity > 0 && fill.averagePrice > 0, false, sell.orderId, quantity,
                    fill.quantity, fill.averagePrice, 0, dispatch,
                    fill.quantity > 0 && fill.averagePrice > 0
                            ? "CNC MARKET SELL executed • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                            : "CNC MARKET SELL accepted • order " + sell.orderId + " • fill not confirmed in time.");
        } catch (Exception e) {
            return new ExecutionResult(true, false, true, sell.orderId, quantity, 0, 0, 0, dispatch,
                    "CNC MARKET SELL accepted; fill confirmation uncertain: " + safeMessage(e));
        }
    }

    static ExecutionResult checkCashOrderExecution(Context context, String orderId, int requestedQty) {
        if (orderId == null || orderId.isEmpty()) return new ExecutionResult(false, false, false, "", requestedQty, 0, 0, 0, 0, "No order ID.");
        try {
            Fill fill = getExecutionOnce(context, orderId);
            return new ExecutionResult(true, fill.quantity >= requestedQty && fill.averagePrice > 0, false, orderId, requestedQty,
                    fill.quantity, fill.averagePrice, 0, 0, fill.status);
        } catch (Exception e) {
            return new ExecutionResult(true, false, true, orderId, requestedQty, 0, 0, 0, 0, safeMessage(e));
        }
    }

    static double getLtpForAutomation(Context context, String symbol) throws Exception { return getLtp(context, symbol); }

    static GttResult createUnivestCncBuyGtt(Context context, String symbol, int quantity, double target, String referenceId) {
        return createGttDetailed(context, symbol, quantity, "CNC", "BUY", "DOWN", target, referenceId);
    }

    static GttResult createUnivestCncStopGtt(Context context, String symbol, int quantity, double trigger, String referenceId) {
        return createGttMarketDetailed(context, symbol, quantity, "CNC", "SELL", "DOWN", trigger, referenceId);
    }

    static Result modifyUnivestCncStopGtt(Context context, String smartOrderId, int quantity, double trigger) {
        if (smartOrderId == null || smartOrderId.isEmpty()) return new Result(false, false, 0, "No protective stop GTT id to modify.");
        try {
            JSONObject order = new JSONObject();
            order.put("order_type", "MARKET");
            order.put("price", JSONObject.NULL);
            order.put("transaction_type", "SELL");
            JSONObject body = new JSONObject();
            body.put("smart_order_type", "GTT");
            body.put("segment", "CASH");
            body.put("quantity", quantity);
            body.put("trigger_price", money(trigger));
            body.put("trigger_direction", "DOWN");
            body.put("order", order);
            HttpResponse r = put(SMART_MODIFY_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return a;
                r = put(SMART_MODIFY_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) return new Result(true, false, r.code, "Protective stop GTT updated • qty " + quantity + " • trigger ₹" + money(trigger));
            return new Result(false, false, r.code, "Protective stop GTT modify rejected HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "Protective stop GTT modification status unknown after timeout; verify Smart Orders before any retry.");
        } catch (Exception e) { return new Result(false, true, 0, "Protective stop GTT modify error: " + safeMessage(e)); }
    }

    static GttStatusResult getCashGttStatus(Context context, String smartOrderId) {
        try {
            HttpResponse r = get(GTT_STATUS_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return new GttStatusResult(false, "", "", a.message);
                r = get(GTT_STATUS_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), AppPrefs.getAccessToken(context), true);
            }
            if (r.code >= 200 && r.code < 300) {
                JSONObject j = new JSONObject(r.body); JSONObject p = j.optJSONObject("payload");
                if (p != null) return new GttStatusResult(true, p.optString("status", ""), p.optString("triggered_at", ""), "OK");
            }
            return new GttStatusResult(false, "", "", "GTT status HTTP " + r.code + ": " + shortText(r.body));
        } catch (Exception e) { return new GttStatusResult(false, "", "", safeMessage(e)); }
    }

    static Result cancelCashGtt(Context context, String smartOrderId) {
        if (smartOrderId == null || smartOrderId.isEmpty()) return new Result(true, false, 0, "No Univest GTT to cancel.");
        try {
            HttpResponse r = postEmpty(GTT_CANCEL_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return a;
                r = postEmpty(GTT_CANCEL_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), AppPrefs.getAccessToken(context), true);
            }
            if (r.code >= 200 && r.code < 300) return new Result(true, false, r.code, "Univest GTT cancelled • " + smartOrderId);
            // If broker says it is already completed/cancelled, cleanup can be treated as done.
            if (r.code == 400 || r.code == 404 || r.code == 409) return new Result(true, false, r.code, "Univest GTT already inactive/finished • " + smartOrderId);
            return new Result(false, false, r.code, "GTT cancel HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "GTT cancellation status unknown after timeout; verify Groww Smart Orders.");
        } catch (Exception e) { return new Result(false, true, 0, "GTT cancellation error: " + safeMessage(e)); }
    }

    static boolean shouldCancelCncSellOrder(String wantedSymbol, String orderSymbol, String product,
                                            String transactionType, String orderStatus, int remainingQuantity) {
        if (wantedSymbol == null || orderSymbol == null || !wantedSymbol.equalsIgnoreCase(orderSymbol)) return false;
        if (!"CNC".equalsIgnoreCase(product)) return false;
        if (!"SELL".equalsIgnoreCase(transactionType)) return false;
        if (remainingQuantity <= 0) return false;
        String st = orderStatus == null ? "" : orderStatus.trim().toUpperCase(Locale.US);
        return !("COMPLETED".equals(st) || "EXECUTED".equals(st) || "CANCELLED".equals(st)
                || "REJECTED".equals(st) || "FAILED".equals(st));
    }

    /**
     * Clears regular pending/open CASH/CNC SELL orders for a symbol before an automated Univest market exit.
     * This prevents a user's forgotten manual target order from reserving the same delivery shares.
     * The method re-lists after cancellation and will not report success while a conflicting sell remains.
     */
    static Result hasOpenCncBuyOrderForSymbol(Context context, String symbol) {
        if (symbol == null || symbol.trim().isEmpty()) return new Result(false, false, 0, "Missing symbol for BUY-order reconciliation.");
        String wanted = symbol.trim().toUpperCase(Locale.US);
        try {
            java.util.ArrayList<String> ids = listOpenCncOrderIds(context, wanted, "BUY");
            return new Result(true, false, ids.isEmpty() ? 200 : 409, ids.isEmpty() ? "No open CNC BUY orders found." : "Open CNC BUY order(s) found: " + ids.size());
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "BUY-order reconciliation timed out.");
        } catch (Exception e) {
            return new Result(false, true, 0, "BUY-order reconciliation failed: " + safeMessage(e));
        }
    }

    static Result cancelOpenCncSellOrdersForSymbol(Context context, String symbol) {
        if (symbol == null || symbol.trim().isEmpty()) return new Result(false, false, 0, "Missing symbol for sell-order reconciliation.");
        String wanted = symbol.trim().toUpperCase(Locale.US);
        try {
            java.util.ArrayList<String> ids = listOpenCncSellOrderIds(context, wanted);
            if (ids.isEmpty()) return new Result(true, false, 200, "No conflicting open CNC SELL orders found.");

            boolean sawUnknown = false;
            for (String id : ids) {
                try {
                    JSONObject body = new JSONObject();
                    body.put("segment", "CASH");
                    body.put("groww_order_id", id);
                    HttpResponse r = post(ORDER_CANCEL_URL, ensureToken(context), body.toString(), true);
                    if (r.code == 401 || r.code == 403) {
                        AppPrefs.clearAccessToken(context);
                        Result auth = authenticate(context);
                        if (!auth.success) return auth;
                        r = post(ORDER_CANCEL_URL, AppPrefs.getAccessToken(context), body.toString(), true);
                    }
                    if (!(r.code >= 200 && r.code < 300)) {
                        // Do not immediately assume failure: the order may have completed/cancelled during the race.
                        // A final re-list below is authoritative for whether a conflict still exists.
                    }
                } catch (SocketTimeoutException e) {
                    sawUnknown = true;
                }
            }

            java.util.ArrayList<String> remaining = listOpenCncSellOrderIds(context, wanted);
            if (!remaining.isEmpty()) {
                return new Result(false, sawUnknown, 0,
                        "Conflicting CNC SELL order(s) still active after cancellation attempt: " + remaining.size() + ".");
            }
            return new Result(true, sawUnknown, 200,
                    "Cleared " + ids.size() + " conflicting open CNC SELL order(s) before automated exit.");
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "Sell-order reconciliation timed out; no automated market sell was sent.");
        } catch (Exception e) {
            return new Result(false, true, 0, "Sell-order reconciliation failed: " + safeMessage(e));
        }
    }

    private static java.util.ArrayList<String> listOpenCncSellOrderIds(Context context, String wantedSymbol) throws Exception {
        return listOpenCncOrderIds(context, wantedSymbol, "SELL");
    }

    private static java.util.ArrayList<String> listOpenCncOrderIds(Context context, String wantedSymbol, String wantedTransaction) throws Exception {
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        for (int page = 0; page < 5; page++) {
            String endpoint = ORDER_LIST_URL + "?segment=CASH&page=" + page + "&page_size=100";
            HttpResponse r = get(endpoint, ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context);
                Result auth = authenticate(context);
                if (!auth.success) throw new IllegalStateException(auth.message);
                r = get(endpoint, AppPrefs.getAccessToken(context), true);
            }
            if (!(r.code >= 200 && r.code < 300)) {
                throw new IllegalStateException("Order list HTTP " + r.code + ": " + shortText(r.body));
            }
            JSONObject root = new JSONObject(r.body);
            JSONObject payload = root.optJSONObject("payload");
            JSONArray list = payload == null ? null : payload.optJSONArray("order_list");
            if (list == null || list.length() == 0) break;
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.optJSONObject(i);
                if (o == null) continue;
                int remaining = o.optInt("remaining_quantity",
                        Math.max(0, o.optInt("quantity", 0) - o.optInt("filled_quantity", 0)));
                String orderSymbol = o.optString("trading_symbol", "");
                String product = o.optString("product", "");
                String transaction = o.optString("transaction_type", "");
                String status = o.optString("order_status", "");
                String st = status == null ? "" : status.trim().toUpperCase(Locale.US);
                boolean terminal = "COMPLETED".equals(st) || "EXECUTED".equals(st) || "CANCELLED".equals(st) || "REJECTED".equals(st) || "FAILED".equals(st);
                if (wantedSymbol.equalsIgnoreCase(orderSymbol) && "CNC".equalsIgnoreCase(product) && wantedTransaction.equalsIgnoreCase(transaction) && remaining > 0 && !terminal) {
                    String id = o.optString("groww_order_id", "");
                    if (!id.isEmpty() && !out.contains(id)) out.add(id);
                }
            }
            if (list.length() < 100) break;
        }
        return out;
    }

    static PositionSnapshot getCncPosition(Context context, String symbol) {
        int positionQty = 0;
        double positionPrice = 0.0;
        int holdingQty = 0;
        double holdingPrice = 0.0;
        boolean positionOk = false;
        boolean holdingsOk = false;
        String positionMsg = "";
        String holdingsMsg = "";

        try {
            String endpoint = POSITION_SYMBOL_URL + "?trading_symbol=" + URLEncoder.encode(symbol, StandardCharsets.UTF_8.name()) + "&segment=CASH";
            HttpResponse r = get(endpoint, ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context);
                if (a.success) r = get(endpoint, AppPrefs.getAccessToken(context), true);
            }
            if (r.code >= 200 && r.code < 300) {
                positionOk = true;
                JSONObject j = new JSONObject(r.body); JSONObject payload = j.optJSONObject("payload");
                JSONArray arr = payload == null ? null : payload.optJSONArray("positions");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject x = arr.optJSONObject(i); if (x == null) continue;
                    if (!symbol.equalsIgnoreCase(x.optString("trading_symbol", symbol))) continue;
                    if (!"CNC".equalsIgnoreCase(x.optString("product", "CNC"))) continue;
                    positionQty = Math.max(positionQty, Math.max(0, x.optInt("quantity", 0)));
                    positionPrice = x.optDouble("net_price", positionPrice);
                }
                positionMsg = "positions OK";
            } else positionMsg = "positions HTTP " + r.code;
        } catch (Exception e) { positionMsg = "positions " + safeMessage(e); }

        try {
            HttpResponse r = get(HOLDINGS_URL, ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context);
                if (a.success) r = get(HOLDINGS_URL, AppPrefs.getAccessToken(context), true);
            }
            if (r.code >= 200 && r.code < 300) {
                holdingsOk = true;
                JSONObject j = new JSONObject(r.body); JSONObject payload = j.optJSONObject("payload");
                JSONArray arr = payload == null ? null : payload.optJSONArray("holdings");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject x = arr.optJSONObject(i); if (x == null) continue;
                    if (!symbol.equalsIgnoreCase(x.optString("trading_symbol", ""))) continue;
                    int total = Math.max(0, x.optInt("quantity", 0));
                    int settledPlusT1 = Math.max(0, x.optInt("demat_free_quantity", 0)) + Math.max(0, x.optInt("t1_quantity", 0));
                    holdingQty = Math.max(total, settledPlusT1);
                    holdingPrice = x.optDouble("average_price", 0.0);
                    break;
                }
                holdingsMsg = "holdings OK";
            } else holdingsMsg = "holdings HTTP " + r.code;
        } catch (Exception e) { holdingsMsg = "holdings " + safeMessage(e); }

        int qty = Math.max(positionQty, holdingQty);
        double price = holdingQty >= positionQty && holdingPrice > 0 ? holdingPrice : positionPrice;
        boolean ok = positionOk || holdingsOk;
        String msg = "CNC reconciliation • position=" + positionQty + " • holding=" + holdingQty + " • " + positionMsg + " • " + holdingsMsg;
        DiagnosticsStore.broker(context, "CNC_RECONCILIATION", symbol, ok, msg);
        return new PositionSnapshot(ok, ok ? qty : -1, price, msg);
    }

    /** Multyfi Intraday notification -> immediate CNC DELIVERY MARKET BUY, then broker-hosted GTT. */
    static MultyfiEntryResult placeMultyfiDeliveryBuyWithHalfPercentNetGtt(Context context, String symbol,
                                                                           int quantity, int savedBudget,
                                                                           String referenceId) {
        OrderSubmit entry = submitMarketOrder(context, symbol, quantity, "CNC", "BUY", referenceId);
        if (!entry.success) return new MultyfiEntryResult(false, false, entry.unknown, entry.orderId, "", 0, 0, 0, 0, 0, entry.message);
        if (entry.orderId.isEmpty()) return new MultyfiEntryResult(true, false, false, "", "", 0, 0, 0, 0, 0,
                "CNC MARKET BUY accepted, but Groww returned no order ID. +0.5% NET GTT not created; verify manually.");
        try {
            Fill fill = awaitExecution(context, entry.orderId, quantity);
            if (fill.quantity < 1 || !(fill.averagePrice > 0)) {
                return new MultyfiEntryResult(true, false, false, entry.orderId, "", 0, 0, 0, 0, 0,
                        "CNC MARKET BUY accepted, but fill price was not confirmed in time. +0.5% NET GTT not created.");
            }
            double tick = 0.05;
            try {
                InstrumentRepository.Instrument i = InstrumentRepository.resolve(InstrumentRepository.load(context), symbol);
                if (i != null && i.tickSize > 0) tick = i.tickSize;
            } catch (Exception ignored) {}
            double desiredNet = Math.max(0.0, savedBudget * 0.005);
            double target = DeliveryNetTarget.targetPriceForNetProfit(fill.averagePrice, fill.quantity, tick, desiredNet);
            double breakEven = DeliveryNetTarget.breakEvenPrice(fill.averagePrice, fill.quantity, tick);
            GttResult gtt = createGttDetailed(context, symbol, fill.quantity, "CNC", "SELL", "UP", target,
                    makeReference("M05", symbol));
            if (!gtt.success) {
                return new MultyfiEntryResult(true, false, gtt.unknown, entry.orderId, "", fill.quantity,
                        fill.averagePrice, target, breakEven, tick,
                        "BUY EXECUTED • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                                + " • +0.5% NET-on-budget GTT ₹" + money(target) + " NOT confirmed: " + gtt.message);
            }
            double est = DeliveryNetTarget.estimatedNetProfit(fill.averagePrice, fill.quantity, target);
            return new MultyfiEntryResult(true, true, false, entry.orderId, gtt.smartOrderId, fill.quantity,
                    fill.averagePrice, target, breakEven, tick,
                    "BUY EXECUTED • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                            + " • +0.5% NET-on-budget GTT SELL ₹" + money(target)
                            + " • estimated net ₹" + money(est) + ".");
        } catch (SocketTimeoutException e) {
            return new MultyfiEntryResult(true, false, true, entry.orderId, "", 0, 0, 0, 0, 0,
                    "BUY accepted, but fill/GTT confirmation timed out. Verify Orders/Smart Orders; no blind retry.");
        } catch (Exception e) {
            return new MultyfiEntryResult(true, false, true, entry.orderId, "", 0, 0, 0, 0, 0,
                    "BUY accepted, but +0.5% NET GTT status is uncertain: " + safeMessage(e));
        }
    }

    static ExecutionResult placeCncMarketSell(Context context, String symbol, int quantity, String referenceId) {
        return placeUnivestCncMarketSell(context, symbol, quantity, referenceId);
    }

    static Result modifyCashGttSellTarget(Context context, String smartOrderId, int quantity, double target) {
        if (smartOrderId == null || smartOrderId.isEmpty()) return new Result(false, false, 0, "No GTT id to modify.");
        try {
            JSONObject order = new JSONObject();
            order.put("order_type", "LIMIT"); order.put("price", money(target)); order.put("transaction_type", "SELL");
            JSONObject body = new JSONObject();
            body.put("smart_order_type", "GTT"); body.put("segment", "CASH"); body.put("quantity", quantity);
            body.put("trigger_price", money(target)); body.put("trigger_direction", "UP"); body.put("order", order);
            HttpResponse r = put(SMART_MODIFY_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return a;
                r = put(SMART_MODIFY_URL + URLEncoder.encode(smartOrderId, StandardCharsets.UTF_8.name()), AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) return new Result(true, false, r.code, "GTT modified to ₹" + money(target));
            return new Result(false, false, r.code, "GTT modify rejected HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "GTT modify status unknown after timeout; verify Smart Orders before any retry.");
        } catch (Exception e) { return new Result(false, true, 0, "GTT modify error: " + safeMessage(e)); }
    }

    /** Multyfi official close -> MIS MARKET short, protected by same-day CASH/MIS OCO. */
    static ShortOcoResult placeMultyfiMisShortWithOco(Context context, String symbol, int budget, double tickSize, String referenceId) {
        try {
            double ltp = getLtp(context, symbol);
            if (!(ltp > 0)) return new ShortOcoResult(false, false, false, 0, 0, 0, 0, "", "No valid LTP for short sizing.");
            int qty = (int)Math.floor(budget / ltp);
            if (qty < 1) return new ShortOcoResult(false, false, false, 0, 0, 0, 0, "", "Saved Multyfi budget cannot short one share at current LTP.");
            OrderSubmit shortEntry = submitMarketOrder(context, symbol, qty, "MIS", "SELL", referenceId);
            if (!shortEntry.success) return new ShortOcoResult(false, false, shortEntry.unknown, qty, 0, 0, 0, "", shortEntry.message);
            if (shortEntry.orderId.isEmpty()) return new ShortOcoResult(true, false, false, qty, 0, 0, 0, "", "MIS short accepted but no order ID returned; OCO not created.");
            Fill fill = awaitExecution(context, shortEntry.orderId, qty);
            if (fill.quantity < 1 || !(fill.averagePrice > 0)) return new ShortOcoResult(true, false, false, qty, 0, 0, 0, "", "MIS short accepted but fill not confirmed; OCO not created.");
            double tick = tickSize > 0 ? tickSize : 0.05;
            double target = IntradayChargeTarget.targetPriceForNetProfit(fill.averagePrice, fill.quantity, tick, budget * 0.005);
            double stop = IntradayChargeTarget.stopTriggerForMaxLoss(fill.averagePrice, fill.quantity, tick, budget * 0.01);
            GttResult oco = createCashMisShortOco(context, symbol, fill.quantity, target, stop, makeReference("MSO", symbol));
            return new ShortOcoResult(true, oco.success, oco.unknown, fill.quantity, fill.averagePrice, target, stop,
                    oco.smartOrderId,
                    "MIS SHORT executed • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                            + " • OCO BUY target ₹" + money(target) + " (+0.5% NET-on-budget)"
                            + " • stop trigger ₹" + money(stop) + " (1% budget-loss guard) • " + oco.message);
        } catch (SocketTimeoutException e) {
            return new ShortOcoResult(false, false, true, 0, 0, 0, 0, "", "Short/OCO status unknown after timeout. Check Groww before retrying.");
        } catch (Exception e) { return new ShortOcoResult(false, false, true, 0, 0, 0, 0, "", "Short/OCO error: " + safeMessage(e)); }
    }

    private static GttResult createCashMisShortOco(Context context, String symbol, int qty, double target, double stop, String referenceId) {
        try {
            JSONObject targetLeg = new JSONObject();
            targetLeg.put("trigger_price", money(target)); targetLeg.put("order_type", "LIMIT"); targetLeg.put("price", money(target));
            JSONObject stopLeg = new JSONObject();
            stopLeg.put("trigger_price", money(stop)); stopLeg.put("order_type", "SL_M"); stopLeg.put("price", JSONObject.NULL);
            JSONObject body = new JSONObject();
            body.put("reference_id", referenceId); body.put("smart_order_type", "OCO"); body.put("segment", "CASH");
            body.put("trading_symbol", symbol); body.put("quantity", qty); body.put("net_position_quantity", -qty);
            body.put("transaction_type", "BUY"); body.put("target", targetLeg); body.put("stop_loss", stopLeg);
            body.put("product_type", "MIS"); body.put("exchange", "NSE"); body.put("duration", "DAY");
            HttpResponse r = post(GTT_URL, ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return new GttResult(false, false, "", a.message);
                r = post(GTT_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String id=""; JSONObject j=new JSONObject(r.body); JSONObject pl=j.optJSONObject("payload"); if (pl!=null) id=pl.optString("smart_order_id","");
                return new GttResult(true, false, id, "MIS OCO active" + (id.isEmpty()?"":" • "+id));
            }
            return new GttResult(false, false, "", "MIS OCO rejected HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) { return new GttResult(false, true, "", "MIS OCO status unknown after timeout; no blind retry."); }
        catch (Exception e) { return new GttResult(false, true, "", "MIS OCO error: " + safeMessage(e)); }
    }

    static ManualResult executeManualLong(Context context, InstrumentRepository.Instrument instrument, int budget) {
        return executeManualTargetTrade(context, instrument, budget, true);
    }

    static ManualResult executeManualShort(Context context, InstrumentRepository.Instrument instrument, int budget) {
        return executeManualTargetTrade(context, instrument, budget, false);
    }

    private static ManualResult executeManualTargetTrade(Context context, InstrumentRepository.Instrument instrument, int budget, boolean isLong) {
        if (instrument == null) return new ManualResult(false, false, false, "Select a valid NSE stock first.");
        if (budget <= 0) return new ManualResult(false, false, false, "Budget is ₹0. Move the slider and SAVE BUDGET first.");
        if (!AppPrefs.isReadyForBuy(context)) return new ManualResult(false, false, false, "Groww connection is not ready. Confirm static IP and refresh/test authentication first.");
        if (isLong && !instrument.buyAllowed) return new ManualResult(false, false, false, instrument.symbol + " is currently marked buy_allowed=0 by the Groww instrument master.");
        if (!isLong && !instrument.sellAllowed) return new ManualResult(false, false, false, instrument.symbol + " is currently marked sell_allowed=0 by the Groww instrument master.");

        try {
            double ltp = getLtp(context, instrument.symbol);
            if (!(ltp > 0.0)) return new ManualResult(false, false, false, "Could not obtain a valid LTP for " + instrument.symbol + ". No order submitted.");
            int quantity = (int) Math.floor(budget / ltp);
            if (quantity < 1) return new ManualResult(false, false, false, instrument.symbol + " LTP ₹" + money(ltp) + " is above the selected ₹" + inr(budget) + " budget.");

            String product = isLong ? "CNC" : "MIS";
            String transaction = isLong ? "BUY" : "SELL";
            String entryRef = makeReference(isLong ? "LG" : "SH", instrument.symbol);
            OrderSubmit entry = submitMarketOrder(context, instrument.symbol, quantity, product, transaction, entryRef);
            if (!entry.success) {
                return new ManualResult(false, false, entry.unknown, (isLong ? "LONG" : "SHORT") + " entry not confirmed: " + entry.message);
            }
            if (entry.orderId.isEmpty()) {
                return new ManualResult(true, false, false, "ENTRY ACCEPTED for " + instrument.symbol + " qty " + quantity + ", but Groww returned no order ID. 1% target was NOT created; verify manually.");
            }

            Fill fill = awaitExecution(context, entry.orderId, quantity);
            if (!fill.confirmed || fill.quantity < 1 || !(fill.averagePrice > 0)) {
                return new ManualResult(true, false, false,
                        "ENTRY ACCEPTED • " + instrument.symbol + " • " + transaction + " " + quantity + " • order " + entry.orderId
                                + ". Execution price was not confirmed in time, so no target was created. Verify Groww manually.");
            }

            double rawTarget = isLong ? fill.averagePrice * 1.01 : fill.averagePrice * 0.99;
            double target = roundTarget(rawTarget, instrument.tickSize, isLong);
            Result targetResult;
            if (isLong) {
                targetResult = createGttTarget(context, instrument.symbol, fill.quantity, "CNC",
                        "SELL", "UP", target, makeReference("LGT", instrument.symbol));
            } else {
                // A short is intraday. Keep its cover as a DAY LIMIT BUY rather than a persistent GTT,
                // so an unfilled target cannot survive the MIS position into a later session.
                targetResult = submitShortCoverLimit(context, instrument.symbol, fill.quantity, target,
                        makeReference("SHT", instrument.symbol));
            }
            if (!targetResult.success) {
                return new ManualResult(true, false, targetResult.unknown,
                        "ENTRY EXECUTED • " + instrument.symbol + " • avg ₹" + money(fill.averagePrice)
                                + " • qty " + fill.quantity + ". 1% target ₹" + money(target) + " was NOT created: " + targetResult.message);
            }

            String side = isLong ? "LONG CNC BUY" : "SHORT MIS SELL";
            String exit = isLong ? "GTT SELL" : "DAY LIMIT BUY-to-cover";
            return new ManualResult(true, true, false,
                    side + " EXECUTED • " + instrument.symbol + " • qty " + fill.quantity + " • avg ₹" + money(fill.averagePrice)
                            + " • " + exit + " target ₹" + money(target) + " (1%).");
        } catch (SocketTimeoutException e) {
            return new ManualResult(false, false, true, "Network timeout before entry status was safely established. Check Groww before retrying to avoid a duplicate trade.");
        } catch (Exception e) {
            return new ManualResult(false, false, true, "Manual trade status uncertain after network/API error: " + safeMessage(e) + ". Check Groww before retrying.");
        }
    }

    private static double getLtp(Context context, String symbol) throws Exception {
        String token = ensureToken(context);
        String key = "NSE_" + symbol;
        String endpoint = LTP_URL + "?segment=CASH&exchange_symbols=" + URLEncoder.encode(key, StandardCharsets.UTF_8.name());
        HttpResponse r = get(endpoint, token, true);
        if (r.code == 401 || r.code == 403) {
            AppPrefs.clearAccessToken(context);
            Result a = authenticate(context);
            if (!a.success) throw new IllegalStateException(a.message);
            r = get(endpoint, AppPrefs.getAccessToken(context), true);
        }
        if (r.code < 200 || r.code >= 300) throw new IllegalStateException("LTP HTTP " + r.code + ": " + shortText(r.body));
        JSONObject json = new JSONObject(r.body);
        JSONObject payload = json.optJSONObject("payload");
        if (payload == null) return -1;
        return payload.optDouble(key, -1);
    }

    private static OrderSubmit submitMarketOrder(Context context, String symbol, int quantity, String product, String transaction, String referenceId) {
        if (quantity <= 0) return new OrderSubmit(false, false, 0, "", "Quantity is zero; order not submitted.");
        try {
            String token = ensureToken(context);
            JSONObject body = new JSONObject();
            body.put("trading_symbol", symbol);
            body.put("quantity", quantity);
            body.put("validity", "DAY");
            body.put("exchange", "NSE");
            body.put("segment", "CASH");
            body.put("product", product);
            body.put("order_type", "MARKET");
            body.put("transaction_type", transaction);
            body.put("order_reference_id", referenceId);

            HttpResponse r = post(ORDER_URL, token, body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context);
                Result auth = authenticate(context);
                if (!auth.success) return new OrderSubmit(false, false, auth.httpCode, "", auth.message);
                // Retry only after an explicit authentication rejection; the rejected request was not accepted as an order.
                r = post(ORDER_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String orderId = "";
                String remark = "Order accepted";
                try {
                    JSONObject json = new JSONObject(r.body);
                    JSONObject payload = json.optJSONObject("payload");
                    if (payload != null) {
                        orderId = payload.optString("groww_order_id", "");
                        remark = payload.optString("remark", remark);
                    }
                } catch (Exception ignored) {}
                String msg = remark + (orderId.isEmpty() ? "" : " • " + orderId);
                DiagnosticsStore.broker(context, "ORDER_" + transaction + "_" + product, symbol, true, msg);
                return new OrderSubmit(true, false, r.code, orderId, msg);
            }
            String reject = transaction + " rejected (HTTP " + r.code + "): " + shortText(r.body);
            DiagnosticsStore.broker(context, "ORDER_" + transaction + "_" + product, symbol, false, reject);
            return new OrderSubmit(false, false, r.code, "", reject);
        } catch (SocketTimeoutException e) {
            return new OrderSubmit(false, true, 0, "", transaction + " status unknown after network timeout. No automatic retry was made to avoid a duplicate order.");
        } catch (Exception e) {
            return new OrderSubmit(false, true, 0, "", transaction + " status unknown after network error: " + safeMessage(e) + ". No automatic retry was made.");
        }
    }

    private static Fill getExecutionOnce(Context context, String orderId) throws Exception {
        String endpoint = ORDER_DETAIL_URL + URLEncoder.encode(orderId, StandardCharsets.UTF_8.name()) + "?segment=CASH";
        HttpResponse r = get(endpoint, ensureToken(context), true);
        if (r.code == 401 || r.code == 403) {
            AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return new Fill(false, 0, 0, "AUTH_FAILED");
            r = get(endpoint, AppPrefs.getAccessToken(context), true);
        }
        if (r.code >= 200 && r.code < 300) {
            JSONObject json = new JSONObject(r.body); JSONObject p = json.optJSONObject("payload");
            if (p != null) {
                int filled = p.optInt("filled_quantity", 0); double avg = p.optDouble("average_fill_price", 0);
                String status = p.optString("order_status", "");
                return new Fill(filled > 0 && avg > 0, filled, avg, status);
            }
        }
        return new Fill(false, 0, 0, "HTTP_" + r.code);
    }

    private static Fill awaitExecution(Context context, String orderId, int requestedQty) throws Exception {
        long deadline = System.currentTimeMillis() + 8000L;
        Fill best = new Fill(false, 0, 0, "UNKNOWN");
        while (System.currentTimeMillis() < deadline) {
            String endpoint = ORDER_DETAIL_URL + URLEncoder.encode(orderId, StandardCharsets.UTF_8.name()) + "?segment=CASH";
            HttpResponse r = get(endpoint, ensureToken(context), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context);
                Result a = authenticate(context);
                if (!a.success) return best;
                continue;
            }
            if (r.code >= 200 && r.code < 300) {
                JSONObject json = new JSONObject(r.body);
                JSONObject p = json.optJSONObject("payload");
                if (p != null) {
                    int filled = p.optInt("filled_quantity", 0);
                    double avg = p.optDouble("average_fill_price", 0);
                    String status = p.optString("order_status", "");
                    if (filled > 0 && avg > 0) best = new Fill(filled >= requestedQty, filled, avg, status);
                    if (filled >= requestedQty && avg > 0) return new Fill(true, filled, avg, status);
                    if ("REJECTED".equalsIgnoreCase(status) || "FAILED".equalsIgnoreCase(status) || "CANCELLED".equalsIgnoreCase(status)) return best;
                }
            }
            Thread.sleep(175L);
        }
        return best;
    }

    private static Result submitShortCoverLimit(Context context, String symbol, int quantity, double target, String referenceId) {
        try {
            JSONObject body = new JSONObject();
            body.put("trading_symbol", symbol);
            body.put("quantity", quantity);
            body.put("validity", "DAY");
            body.put("exchange", "NSE");
            body.put("segment", "CASH");
            body.put("product", "MIS");
            body.put("order_type", "LIMIT");
            body.put("price", money(target));
            body.put("transaction_type", "BUY");
            body.put("order_reference_id", referenceId);

            HttpResponse r = post(ORDER_URL, ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context);
                Result a = authenticate(context);
                if (!a.success) return a;
                r = post(ORDER_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String id = "";
                try {
                    JSONObject json = new JSONObject(r.body);
                    JSONObject payload = json.optJSONObject("payload");
                    if (payload != null) id = payload.optString("groww_order_id", "");
                } catch (Exception ignored) {}
                return new Result(true, false, r.code, "DAY LIMIT BUY-to-cover target active" + (id.isEmpty() ? "" : " • " + id));
            }
            return new Result(false, false, r.code, "Short cover target rejected (HTTP " + r.code + "): " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "Short cover target status unknown after timeout. Verify Orders in Groww; no automatic retry was made.");
        } catch (Exception e) {
            return new Result(false, true, 0, "Short cover target status unknown after network error: " + safeMessage(e) + ". Verify Groww before retrying.");
        }
    }

    private static GttResult createGttMarketDetailed(Context context, String symbol, int quantity, String product,
                                                     String transaction, String direction, double trigger, String referenceId) {
        try {
            JSONObject order = new JSONObject();
            order.put("order_type", "MARKET");
            order.put("price", JSONObject.NULL);
            order.put("transaction_type", transaction);
            JSONObject body = new JSONObject();
            body.put("reference_id", referenceId);
            body.put("smart_order_type", "GTT");
            body.put("segment", "CASH");
            body.put("trading_symbol", symbol);
            body.put("quantity", quantity);
            body.put("trigger_price", money(trigger));
            body.put("trigger_direction", direction);
            body.put("order", order);
            body.put("product_type", product);
            body.put("exchange", "NSE");
            body.put("duration", "DAY");
            HttpResponse r = post(GTT_URL, ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return new GttResult(false, false, "", a.message);
                r = post(GTT_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String id = ""; JSONObject jo = new JSONObject(r.body); JSONObject pl = jo.optJSONObject("payload");
                if (pl != null) id = pl.optString("smart_order_id", "");
                return new GttResult(true, false, id, "MARKET GTT active" + (id.isEmpty() ? "" : " • " + id));
            }
            return new GttResult(false, false, "", "MARKET GTT rejected HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new GttResult(false, true, "", "MARKET GTT status unknown after timeout. No blind retry.");
        } catch (Exception e) { return new GttResult(false, true, "", "MARKET GTT error: " + safeMessage(e)); }
    }

    private static GttResult createGttDetailed(Context context, String symbol, int quantity, String product,
                                               String transaction, String direction, double target, String referenceId) {
        try {
            JSONObject order = new JSONObject();
            order.put("order_type", "LIMIT"); order.put("price", money(target)); order.put("transaction_type", transaction);
            JSONObject body = new JSONObject();
            body.put("reference_id", referenceId); body.put("smart_order_type", "GTT"); body.put("segment", "CASH");
            body.put("trading_symbol", symbol); body.put("quantity", quantity); body.put("trigger_price", money(target));
            body.put("trigger_direction", direction); body.put("order", order); body.put("product_type", product);
            body.put("exchange", "NSE"); body.put("duration", "DAY");
            HttpResponse r = post(GTT_URL, ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context); Result a = authenticate(context); if (!a.success) return new GttResult(false, false, "", a.message);
                r = post(GTT_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String id = ""; JSONObject j = new JSONObject(r.body); JSONObject p = j.optJSONObject("payload");
                if (p != null) id = p.optString("smart_order_id", "");
                return new GttResult(true, false, id, "GTT active" + (id.isEmpty() ? "" : " • " + id));
            }
            return new GttResult(false, false, "", "GTT rejected HTTP " + r.code + ": " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new GttResult(false, true, "", "GTT status unknown after timeout. No blind retry.");
        } catch (Exception e) { return new GttResult(false, true, "", "GTT error: " + safeMessage(e)); }
    }

    private static Result createGttTarget(Context context, String symbol, int quantity, String product,
                                          String transaction, String direction, double target, String referenceId) {
        try {
            JSONObject order = new JSONObject();
            order.put("order_type", "LIMIT");
            order.put("price", money(target));
            order.put("transaction_type", transaction);

            JSONObject body = new JSONObject();
            body.put("reference_id", referenceId);
            body.put("smart_order_type", "GTT");
            body.put("segment", "CASH");
            body.put("trading_symbol", symbol);
            body.put("quantity", quantity);
            body.put("trigger_price", money(target));
            body.put("trigger_direction", direction);
            body.put("order", order);
            body.put("product_type", product);
            body.put("exchange", "NSE");
            body.put("duration", "DAY");

            HttpResponse r = post(GTT_URL, ensureToken(context), body.toString(), true);
            if (r.code == 401 || r.code == 403) {
                AppPrefs.clearAccessToken(context);
                Result a = authenticate(context);
                if (!a.success) return a;
                r = post(GTT_URL, AppPrefs.getAccessToken(context), body.toString(), true);
            }
            if (r.code >= 200 && r.code < 300) {
                String id = "";
                try {
                    JSONObject json = new JSONObject(r.body);
                    JSONObject p = json.optJSONObject("payload");
                    if (p != null) id = p.optString("smart_order_id", "");
                } catch (Exception ignored) {}
                return new Result(true, false, r.code, "GTT target active" + (id.isEmpty() ? "" : " • " + id));
            }
            return new Result(false, false, r.code, "GTT rejected (HTTP " + r.code + "): " + shortText(r.body));
        } catch (SocketTimeoutException e) {
            return new Result(false, true, 0, "GTT status unknown after timeout. Verify Smart Orders in Groww; no automatic retry was made.");
        } catch (Exception e) {
            return new Result(false, true, 0, "GTT status unknown after network error: " + safeMessage(e) + ". Verify Groww before retrying.");
        }
    }

    private static String ensureToken(Context context) throws Exception {
        String token = AppPrefs.getAccessToken(context);
        if (!token.isEmpty()) return token;
        Result a = authenticate(context);
        if (!a.success) throw new IllegalStateException(a.message);
        return AppPrefs.getAccessToken(context);
    }

    static double roundTarget(double raw, double tick, boolean isLong) {
        double t = tick > 0 ? tick : 0.05;
        double units = raw / t;
        double rounded = (isLong ? Math.ceil(units - 1e-9) : Math.floor(units + 1e-9)) * t;
        return Math.max(t, Math.round(rounded * 10000.0) / 10000.0);
    }

    private static String makeReference(String prefix, String symbol) {
        String base = prefix + Long.toString(System.currentTimeMillis(), 36).toUpperCase(Locale.US)
                + symbol.replaceAll("[^A-Z0-9]", "");
        if (base.length() > 20) base = base.substring(0, 20);
        while (base.length() < 8) base += "0";
        return base;
    }

    private static final class HttpResponse {
        final int code;
        final String body;
        HttpResponse(int code, String body) { this.code = code; this.body = body; }
    }

    private static HttpResponse get(String endpoint, String bearer, boolean apiVersion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(5000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (apiVersion) c.setRequestProperty("X-API-VERSION", "1.0");
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(stream);
        c.disconnect();
        return new HttpResponse(code, body);
    }

    private static HttpResponse post(String endpoint, String bearer, String json, boolean apiVersion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(5000);
        c.setReadTimeout(10000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (apiVersion) c.setRequestProperty("X-API-VERSION", "1.0");
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(stream);
        c.disconnect();
        return new HttpResponse(code, body);
    }

    private static HttpResponse put(String endpoint, String bearer, String json, boolean apiVersion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("PUT"); c.setConnectTimeout(5000); c.setReadTimeout(10000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + bearer); if (apiVersion) c.setRequestProperty("X-API-VERSION", "1.0");
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(stream); c.disconnect(); return new HttpResponse(code, body);
    }

    private static HttpResponse postEmpty(String endpoint, String bearer, boolean apiVersion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(5000); c.setReadTimeout(10000); c.setDoOutput(true);
        c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (apiVersion) c.setRequestProperty("X-API-VERSION", "1.0");
        c.setFixedLengthStreamingMode(0);
        try (OutputStream os = c.getOutputStream()) { os.flush(); }
        int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(stream); c.disconnect(); return new HttpResponse(code, body);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static String shortText(String s) {
        if (s == null || s.isEmpty()) return "no response body";
        String clean = s.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() <= 220 ? clean : clean.substring(0, 220) + "…";
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null || m.trim().isEmpty() ? e.getClass().getSimpleName() : m;
    }

    private static String money(double v) { return String.format(Locale.US, "%.2f", v); }
    private static String inr(int v) { return String.format(Locale.US, "%,d", v); }

    static String generateTotp(String base32Secret, long nowMillis) throws GeneralSecurityException {
        byte[] key = decodeBase32(normalizeTotpSecret(base32Secret));
        if (key.length == 0) throw new GeneralSecurityException("TOTP Base32 secret decoded to zero bytes");
        long counter = (nowMillis / 1000L) / 30L;
        byte[] data = ByteBuffer.allocate(8).putLong(counter).array();
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key, "HmacSHA1"));
        byte[] h = mac.doFinal(data);
        int offset = h[h.length - 1] & 0x0F;
        int binary = ((h[offset] & 0x7F) << 24)
                | ((h[offset + 1] & 0xFF) << 16)
                | ((h[offset + 2] & 0xFF) << 8)
                | (h[offset + 3] & 0xFF);
        int otp = binary % 1_000_000;
        return String.format(Locale.US, "%06d", otp);
    }

    static String normalizeTotpSecret(String input) {
        if (input == null) return "";
        String s = input.toUpperCase(Locale.US).replaceAll("\\s+", "").replace("-", "").replace("=", "");
        if (!s.isEmpty() && !s.matches("[A-Z2-7]+")) {
            throw new IllegalArgumentException("TOTP secret contains non-Base32 characters");
        }
        return s;
    }

    private static byte[] decodeBase32(String input) {
        String s = normalizeTotpSecret(input);
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        int buffer = 0;
        int bitsLeft = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            int val;
            if (ch >= 'A' && ch <= 'Z') val = ch - 'A';
            else if (ch >= '2' && ch <= '7') val = ch - '2' + 26;
            else throw new IllegalArgumentException("Invalid Base32 character in TOTP secret");
            buffer = (buffer << 5) | val;
            bitsLeft += 5;
            if (bitsLeft >= 8) {
                out.write((buffer >> (bitsLeft - 8)) & 0xFF);
                bitsLeft -= 8;
            }
        }
        return out.toByteArray();
    }
}
