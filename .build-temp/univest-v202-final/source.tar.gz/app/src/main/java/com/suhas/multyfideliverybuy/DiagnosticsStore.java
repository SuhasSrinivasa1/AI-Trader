package com.suhas.multyfideliverybuy;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class DiagnosticsStore {
    private static final String DIR = "univest_diagnostics";
    private static final String ARCHIVE = "archive";
    private static final String DAY_MARKER = "active_day.txt";
    private static final Object LOCK = new Object();
    private static final String[] STREAMS = {"notifications", "trades", "errors", "broker", "runtime"};

    private DiagnosticsStore() {}

    static void notification(Context c, String packageName, String raw, UnivestParser.Signal signal) {
        JSONObject d = new JSONObject();
        put(d, "package", packageName); put(d, "raw", raw);
        put(d, "signalType", signal == null ? "NONE" : signal.type.name());
        put(d, "signalSymbol", signal == null ? "" : signal.symbol);
        append(c, "notifications", "NOTIFICATION_RECEIVED", signal == null ? "" : signal.symbol, d);
    }

    static void notification(Context c, String packageName, String raw) { notification(c, packageName, raw, null); }

    static void runtime(Context c, String event, String symbol, String message) {
        JSONObject d = new JSONObject(); put(d, "message", message);
        append(c, "runtime", event, symbol, d);
    }

    static void trade(Context c, String event, String symbol, String message, GrowwClient.ExecutionResult r) {
        JSONObject d = new JSONObject();
        put(d, "message", message);
        if (r != null) {
            put(d, "submitted", r.submitted); put(d, "filled", r.filled); put(d, "unknown", r.unknown);
            put(d, "orderId", r.orderId); put(d, "requestedQuantity", r.requestedQuantity);
            put(d, "filledQuantity", r.filledQuantity); put(d, "averagePrice", r.averagePrice);
            put(d, "sizingLtp", r.sizingLtp); put(d, "dispatchAtMillis", r.dispatchAtMillis);
            put(d, "brokerMessage", r.message);
        }
        append(c, "trades", event, symbol, d);
    }

    static void broker(Context c, String event, String symbol, boolean ok, String message) {
        JSONObject d = new JSONObject(); put(d, "ok", ok); put(d, "message", message);
        append(c, "broker", event, symbol, d);
    }

    static void error(Context c, String event, String symbol, String message, Throwable t) {
        JSONObject d = new JSONObject(); put(d, "message", message);
        if (t != null) { put(d, "exception", t.getClass().getName()); put(d, "exceptionMessage", t.getMessage()); }
        append(c, "errors", event, symbol, d);
    }

    private static void append(Context c, String stream, String event, String symbol, JSONObject detail) {
        synchronized (LOCK) {
            try {
                rotateIfNeededLocked(c);
                File dir = dir(c); if (!dir.exists()) dir.mkdirs();
                long now = System.currentTimeMillis();
                JSONObject row = new JSONObject();
                row.put("timestamp", iso(now)); row.put("timestampMillis", now);
                row.put("stream", stream); row.put("event", event);
                row.put("symbol", symbol == null ? "" : symbol); row.put("detail", detail == null ? new JSONObject() : detail);
                File f = new File(dir, stream + ".jsonl");
                try (Writer w = new OutputStreamWriter(new FileOutputStream(f, true), StandardCharsets.UTF_8)) {
                    w.write(row.toString()); w.write('\n');
                }
            } catch (Exception ignored) {}
        }
    }

    static void rotateIfNeeded(Context c) { synchronized (LOCK) { try { rotateIfNeededLocked(c); } catch (Exception ignored) {} } }

    private static void rotateIfNeededLocked(Context c) throws Exception {
        File d = dir(c); if (!d.exists()) d.mkdirs();
        String today = day(System.currentTimeMillis());
        File marker = new File(d, DAY_MARKER);
        String active = marker.exists() ? readSmall(marker).trim() : "";
        if (active.isEmpty()) { writeSmall(marker, today); return; }
        if (active.equals(today)) return;
        File archiveDay = new File(new File(d, ARCHIVE), active); if (!archiveDay.exists()) archiveDay.mkdirs();
        for (String s : STREAMS) {
            File current = new File(d, s + ".jsonl");
            if (!current.exists() || current.length() == 0) continue;
            File dest = new File(archiveDay, s + ".jsonl");
            if (!current.renameTo(dest)) copyAndDelete(current, dest);
        }
        writeSmall(marker, today);
    }

    static String recent(Context c, int maxLines) { return recentOperationalToday(c, maxLines); }

    static String recentOperationalToday(Context c, int maxLines) {
        return recentFiltered(c, "runtime", maxLines, false, true);
    }

    static String recentStreamToday(Context c, String stream, int maxLines) {
        return recentFiltered(c, stream, maxLines, false, false);
    }

    static String recentSignalNotificationsToday(Context c, int maxLines) {
        return recentFiltered(c, "notifications", maxLines, true, false);
    }

    static String recentStream(Context c, String stream, int maxLines) { return recentStreamToday(c, stream, maxLines); }

    private static String recentFiltered(Context c, String stream, int maxLines, boolean signalsOnly, boolean operationalRuntime) {
        String safeStream = "runtime";
        for (String candidate : STREAMS) if (candidate.equals(stream)) { safeStream = candidate; break; }
        ArrayDeque<String> q = new ArrayDeque<>();
        File f = new File(dir(c), safeStream + ".jsonl");
        if (!f.exists()) return "No " + safeStream + " events recorded today.";
        String today = day(System.currentTimeMillis());
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    JSONObject j = new JSONObject(line);
                    if (!j.optString("timestamp", "").startsWith(today)) continue;
                    JSONObject d = j.optJSONObject("detail");
                    if (signalsOnly && (d == null || "NONE".equals(d.optString("signalType", "NONE")))) continue;
                    if (operationalRuntime && "UNIVEST_NOTIFICATION_NO_TRADE".equals(j.optString("event"))) continue;
                    q.addLast(line); while (q.size() > maxLines) q.removeFirst();
                } catch (Exception ignored) {}
            }
        } catch (Exception e) { return "Unable to read diagnostics: " + e.getMessage(); }
        StringBuilder out = new StringBuilder();
        for (String line : q) {
            try {
                JSONObject j = new JSONObject(line); JSONObject d = j.optJSONObject("detail");
                if (out.length() > 0) out.append("\n\n");
                out.append(j.optString("timestamp")).append("  ").append(j.optString("event"));
                String sym = j.optString("symbol"); if (!sym.isEmpty()) out.append(" • ").append(sym);
                if (d != null) {
                    String raw = d.optString("raw"); String message = d.optString("message");
                    String orderId = d.optString("orderId"); String brokerMessage = d.optString("brokerMessage");
                    if (!raw.isEmpty()) out.append("\n").append(raw.replace('\n', ' '));
                    else if (!message.isEmpty()) out.append("\n").append(message);
                    if (!orderId.isEmpty()) out.append("\nOrder: ").append(orderId);
                    if (!brokerMessage.isEmpty() && !brokerMessage.equals(message)) out.append("\nBroker: ").append(brokerMessage);
                }
            } catch (Exception ignored) {}
        }
        return out.length() == 0 ? "No " + safeStream + " events recorded today." : out.toString();
    }

    static File createExport(Context c) throws Exception {
        synchronized (LOCK) {
            rotateIfNeededLocked(c);
            File out = new File(c.getCacheDir(), "Univest-Debug-" + fileStamp() + ".zip");
            try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
                File d = dir(c);
                for (String s : STREAMS) {
                    File f = new File(d, s + ".jsonl");
                    if (f.exists()) addFile(zip, f, "today/" + s + ".jsonl"); else addText(zip, "today/" + s + ".jsonl", "");
                }
                File archive = new File(d, ARCHIVE); if (archive.exists()) addDirectory(zip, archive, "archive/");
                addText(zip, "snapshot.json", snapshot(c).toString(2));
                addText(zip, "README.txt",
                        "Univest AutoTrade diagnostic export\n" +
                        "today/ contains the current IST trading-day logs. archive/ retains prior-day logs.\n" +
                        "Contains Univest notifications, parser/runtime decisions, broker outcomes, trades and errors.\n" +
                        "It intentionally does NOT export the Groww TOTP token, TOTP secret or access token.\n");
            }
            return out;
        }
    }

    private static JSONObject snapshot(Context c) {
        JSONObject j = new JSONObject();
        try {
            j.put("app", "Univest AutoTrade"); j.put("version", "2.0.2"); j.put("versionCode", 202);
            j.put("sourcePackageLock", "com.univest.capp"); j.put("productLock", "CNC DELIVERY ONLY");
            j.put("entryBudget", UnivestManager.ENTRY_BUDGET); j.put("reentryBudget", UnivestManager.REENTRY_BUDGET);
            j.put("averageBudget", UnivestManager.AVERAGE_BUDGET);
            JSONArray levels = new JSONArray(); levels.put(2); levels.put(4); levels.put(6); levels.put(8);
            j.put("averageLevelsPct", levels);
            j.put("enabled", AppPrefs.isUnivestEnabled(c)); j.put("executionMode", AppPrefs.isLiveTrading(c) ? "LIVE" : "PAPER"); j.put("growwReady", AppPrefs.isReadyForBuy(c));
            j.put("staticIpMatch", AppPrefs.isStaticIpMatch(c)); j.put("lastDetectedIp", AppPrefs.getLastDetectedIp(c));
            j.put("lastStatus", AppPrefs.getUnivestStatus(c)); j.put("pendingSignals", PendingSignalStore.count(c));
            JSONArray states = new JSONArray(); for (UnivestStateStore.State s : UnivestStateStore.all(c)) states.put(s.toJson()); j.put("states", states);
        } catch (Exception ignored) {}
        return j;
    }

    static void clear(Context c) {
        synchronized (LOCK) {
            File d = dir(c); for (String s : STREAMS) { File f = new File(d, s + ".jsonl"); if (f.exists()) f.delete(); }
        }
    }

    private static File dir(Context c) { return new File(c.getFilesDir(), DIR); }
    private static void addDirectory(ZipOutputStream zip, File dir, String prefix) throws Exception {
        File[] files = dir.listFiles(); if (files == null) return;
        for (File f : files) { if (f.isDirectory()) addDirectory(zip, f, prefix + f.getName() + "/"); else addFile(zip, f, prefix + f.getName()); }
    }
    private static void addFile(ZipOutputStream zip, File f, String name) throws Exception {
        zip.putNextEntry(new ZipEntry(name)); try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) zip.write(b, 0, n); } zip.closeEntry();
    }
    private static void addText(ZipOutputStream zip, String name, String text) throws Exception { zip.putNextEntry(new ZipEntry(name)); zip.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8)); zip.closeEntry(); }
    private static void put(JSONObject j, String k, Object v) { try { j.put(k, v == null ? JSONObject.NULL : v); } catch (Exception ignored) {} }
    private static String iso(long ms) { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); return f.format(new Date(ms)); }
    private static String day(long ms) { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); return f.format(new Date(ms)); }
    private static String fileStamp() { SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); return f.format(new Date()); }
    private static String readSmall(File f) throws Exception { try (BufferedReader br = new BufferedReader(new FileReader(f))) { String s=br.readLine(); return s==null?"":s; } }
    private static void writeSmall(File f, String s) throws Exception { try (Writer w=new OutputStreamWriter(new FileOutputStream(f,false),StandardCharsets.UTF_8)){ w.write(s==null?"":s); } }
    private static void copyAndDelete(File src, File dst) throws Exception { try(FileInputStream in=new FileInputStream(src); FileOutputStream out=new FileOutputStream(dst)){ byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n);} src.delete(); }
}
