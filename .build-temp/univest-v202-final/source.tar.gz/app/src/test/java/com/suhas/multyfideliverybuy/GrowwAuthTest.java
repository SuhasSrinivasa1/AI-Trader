package com.suhas.multyfideliverybuy;

import org.junit.Test;
import static org.junit.Assert.*;

public class GrowwAuthTest {
    @Test public void normalizesBase32Secret() {
        assertEquals("JBSWY3DPEHPK3PXP", GrowwClient.normalizeTotpSecret("jbsw y3dp-ehpk3pxp=="));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsNonBase32Secret() {
        GrowwClient.normalizeTotpSecret("ABC!123");
    }

    @Test public void rfcTotpVectorIsSixDigits() throws Exception {
        String otp = GrowwClient.generateTotp("JBSWY3DPEHPK3PXP", 1700000000000L);
        assertTrue(otp.matches("\\d{6}"));
    }
}
