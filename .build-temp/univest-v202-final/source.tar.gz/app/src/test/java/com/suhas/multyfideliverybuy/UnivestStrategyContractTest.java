package com.suhas.multyfideliverybuy;

import org.junit.Test;
import static org.junit.Assert.*;

public class UnivestStrategyContractTest {
    @Test public void fixedBudgetsAreLocked() {
        assertEquals(20000, UnivestManager.ENTRY_BUDGET);
        assertEquals(5000, UnivestManager.REENTRY_BUDGET);
        assertEquals(5000, UnivestManager.AVERAGE_BUDGET);
        assertEquals(4, UnivestManager.MAX_AVERAGE_LEVELS);
    }
    @Test public void downwardAveragingUsesOriginalEntryAnchorEveryTwoPercent() {
        assertEquals(98.00, UnivestManager.averageTriggerPrice(100.00, 0.05, 0), 0.0001);
        assertEquals(96.00, UnivestManager.averageTriggerPrice(100.00, 0.05, 1), 0.0001);
        assertEquals(94.00, UnivestManager.averageTriggerPrice(100.00, 0.05, 2), 0.0001);
        assertEquals(92.00, UnivestManager.averageTriggerPrice(100.00, 0.05, 3), 0.0001);
        assertEquals(50, UnivestManager.averageQuantity(100.00));
        assertEquals(0.0, UnivestManager.averageTriggerPrice(100.00, 0.05, 4), 0.0001);
    }

    @Test public void exitedSymbolCanStartNewRecommendationCycle() {
        assertTrue(UnivestStateStore.canReservePhase(UnivestStateStore.EXITED));
        assertFalse(UnivestStateStore.canReservePhase(UnivestStateStore.ACTIVE));
        assertTrue(UnivestStateStore.canExecuteReservedPhase(UnivestStateStore.ENTRY_PENDING));
    }
    @Test public void companyNameNormalizationRemovesLegalSuffixes() {
        assertEquals("TATA MOTORS", InstrumentRepository.normalizedName("Tata Motors Limited"));
        assertEquals("TATA MOTORS", InstrumentRepository.normalizedName("TATA MOTORS LTD."));
    }
    @Test public void sourcePackageIsStrictlyUnivest() {
        assertEquals("com.univest.capp", MultyfiNotificationService.UNIVEST_PACKAGE);
    }
}
