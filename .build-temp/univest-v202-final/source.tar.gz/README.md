# Multyfi Delivery Buy — v1.2.0

This is an in-place update to v1.0.1. The existing Multyfi notification BUY engine stays unchanged; v1.1.0 adds a separate manual LONG / SHORT launcher.

## Existing Multyfi automation — unchanged

- Intraday release → ₹1,00,000 nominal budget → Groww `NSE / CASH / CNC / MARKET / BUY`.
- Swing release → ₹10,000 nominal budget when Swing toggle is ON.
- Multibagger release → ₹10,000 nominal budget when Multibagger toggle is ON.
- Later Multyfi close/exit/profit/stop notifications remain ignored.
- Static-IP and Groww authentication readiness remain required before ARM.
- The Multyfi notification path still contains no SELL, MIS, GTT, stop-loss, target, trailing, re-entry, P&L, position or holdings logic.

## New manual budget

- Shared LONG/SHORT slider from ₹0 to ₹1,00,000 in ₹10,000 increments.
- Default is ₹50,000.
- The saved amount is a nominal notional budget. Because entry is a MARKET order, the final executed notional can differ slightly as the market moves.

## New LONG section

- Search/select an NSE CASH equity from the Groww instrument master.
- A single LTP lookup is made only at button press to calculate quantity: `floor(budget / LTP)`.
- Entry: `NSE / CASH / CNC / MARKET / BUY`.
- The app polls only the Groww order-detail endpoint briefly to confirm actual fill quantity and average fill price; it does not monitor the stock price.
- Target: actual average fill × 1.01, rounded in the favourable direction to the instrument tick size.
- A broker-hosted Groww GTT is then created with `SELL`, `UP`, `CNC`, `LIMIT` at the target.
- No stop-loss.

## New SHORT section

- Shorting necessarily opens with `SELL`, not `BUY`.
- Entry: `NSE / CASH / MIS / MARKET / SELL`, producing a negative intraday position when accepted/executed.
- Target: actual average fill × 0.99, rounded in the favourable direction to the instrument tick size.
- A `DAY` `LIMIT BUY` with product `MIS` is then placed at the 1% lower target to cover the short. This target is broker/exchange hosted and needs no app price monitoring.
- No stop-loss.
- MIS cannot be carried overnight. Groww/exchange end-of-day square-off behaviour is outside this app.

## Important interpretation of “no sell logic”

The app still has no active exit engine, price watcher, trailing logic, stop-loss engine, or reaction to Multyfi closure messages. However, a LONG +1% GTT target is technically a future SELL instruction stored at Groww. That one-time broker-hosted target is required by the requested LONG target behaviour. For SHORT, the target is a same-day BUY-to-cover limit order, not a persistent GTT, so it does not survive the intraday position into a later session.

## Stock universe

The APK bundles an NSE CASH EQ snapshot generated from Groww's official instrument CSV during CI. The app also refreshes that universe from the same official Groww CSV in the background when stale, keeping autocomplete available immediately from the bundled/cached list.


## v1.1.1 — Multyfi Intraday net-1% GTT

- The Multyfi INTRADAY entry logic is unchanged: ₹1,00,000 nominal budget → immediate `NSE / CASH / CNC / MARKET / BUY` using the notification price only for quantity sizing.
- After Groww accepts the order, the app briefly polls only order-detail to get the actual fill quantity and average fill price.
- It estimates current Groww/NSE delivery buy+sell charges, including conservative delivery DP sell charges, and calculates the GTT price required for **at least 1.00% net profit on executed buy value** after those estimated charges.
- Because charges exist, the gross price target will normally be a little above +1%.
- The target is rounded upward to the official instrument tick size and stored as a Groww-hosted `CNC / SELL / UP / LIMIT` GTT.
- No LTP lookup, price monitoring, stop-loss, trailing, re-entry, Multyfi-close reaction, position polling, holdings polling, cancel, or modify logic is added to the Multyfi hot path.
- Swing and Multibagger notification BUY behavior remains unchanged in v1.1.1.


## v1.1.2 — saved Multyfi Intraday budget

- Dedicated Intraday slider: ₹10,000 to ₹1,00,000 in ₹10,000 steps, with explicit SAVE INTRADAY BUDGET.
- Default remains ₹1,00,000 until changed.
- Only Multyfi INTRADAY sizing uses this slider. Swing/Multibagger and manual LONG/SHORT budgets are unchanged.
- The hot path still uses the Multyfi notification reference price for `floor(savedBudget/referencePrice)` and immediately submits the same NSE/CASH/CNC/MARKET/BUY; no pre-buy LTP request is added.
- As soon as Groww order-detail confirms EXECUTED quantity and average price, the app immediately submits the broker-hosted CNC GTT SELL target calculated for at least 1.00% estimated net delivery profit. It does not wait for the Holdings UI or settlement display.
- GTT triggering/execution is broker-side; there is still no stock-price watcher in the app.


## v1.2.0 — Univest equity-only delivery automation

This release adds a completely separate Univest module. It does not change the existing Multyfi entry/product logic.

- Univest toggle is OFF by default and requires current Groww authentication/static-IP readiness before it can be enabled.
- Univest only accepts equity/stock notifications. Notifications containing Options, Futures/F&O/FNO, Commodity/MCX, Currency/Forex, call option or put option language are ignored.
- Screenshot-supported entry pattern: `New Advisory Pick` + `STOCK: <NSE symbol>`; screenshot-supported exit pattern: `Equity Profit of the Day` + `Stock: <symbol>`. Additional explicit equity book-profit/close phrases are accepted.
- Every new Univest equity entry uses a fixed ₹20,000 nominal budget and is always `NSE / CASH / CNC / MARKET / BUY` (delivery). Univest never uses MIS.
- Because the Univest notification does not include an entry price, the hot path performs exactly one Groww LTP lookup only to calculate `floor(₹20,000/LTP)`, then immediately submits the CNC MARKET BUY. No technical analysis, candles, news, holdings or positions lookup is inserted before that BUY.
- After the actual entry fill, the original average execution price is the averaging anchor. One broker-hosted CNC BUY GTT is active at a time: ₹5,000 at −2%, then after fill confirmation ₹5,000 at −4%, −6% and −8%. This allows at most four downward averages. A separate broker-hosted CNC SELL GTT is armed at −20% from the original executed entry and resized to the full tracked Univest quantity after each confirmed add.
- Averaging levels remain anchored to the original entry, not a moving weighted-average threshold.
- While active, the app checks LTP on a low-frequency 5-second monitor for the ₹2,500 NET profit-capture rule. Net profit is estimated after tracked buy charges plus estimated delivery sell charges. A ₹100 cushion is required before the MARKET SELL dispatch to reduce the risk that slippage/charges leave realised net below ₹2,500.
- After a completed profit capture, if Univest has not closed the recommendation, exactly one ₹20,000 broker-hosted re-entry GTT is armed near the original entry price. After that one re-entry is used, a second profit capture leaves the strategy flat until Univest officially closes it.
- Univest official profit-booked/close notification is authoritative. A dedicated exit executor immediately submits a tracked-quantity `CNC / MARKET / SELL`, then cancels the Univest-managed averaging/re-entry GTT. If already flat, no SELL is sent and the app records `NO HOLDING — already sold earlier` while cancelling the pending Univest re-entry GTT.
- Univest state and GTT IDs are persisted locally so the notification-listener monitor can reconcile after service recreation.
- The Univest module only cleans GTTs it created. It does not cancel Multyfi/manual GTTs, even if the same stock symbol is recommended by another strategy.

### Important execution notes

- ₹20,000 and ₹5,000 are nominal budgets. Whole-share sizing means actual deployed capital can be lower.
- Market BUY/SELL execution price can differ from the LTP used for sizing or profit detection.
- The ₹2,500 rule is an estimated-net trigger, not a guarantee of an exact realised ₹2,500 after market slippage or later broker/contract-note adjustments.
- A GTT trigger submits the configured LIMIT BUY to Groww/exchange. Triggering is not the same as guaranteed execution.


## v1.4.0 — fresh signed UI release

- Refreshed dark control-center UI and clearer strategy wording.
- Univest is always NSE CASH/CNC DELIVERY and never MIS, with saved ₹0–₹1,00,000 entry budget.
- Univest averaging remains fixed at ₹5,000 at −2%, −4%, −6% from original executed entry; ₹2,500 estimated NET profit capture retained.
- Multyfi equity entries remain CNC DELIVERY even when source labels the call Intraday.
- Multyfi equity primary target is +0.5% estimated NET profit on entry budget, with deterministic first-spike fallback retained.
- Authoritative Multyfi close/end may start the separate MIS short after delivery reconciliation, with +0.5% estimated NET target and 1% budget-loss stop guard.
- Fresh signing identity is generated for this release because the previous installation was intentionally removed. Keep the signing backup for future in-place upgrades.


## v1.4.1 — Univest duration gate

- Univest new equity ENTRY is eligible only when the notification explicitly carries a duration from 1 to 3 months inclusive.
- Examples accepted: 1 Month, 2 Months, 3 Months, 1-2 Months, 1-3 Months.
- Durations above 3 months, below 1 month, non-month durations, and new entries with no supported duration are ignored.
- This duration gate applies only to new Univest entries. Existing-position Univest Profit Booked / Close / Exit notifications remain actionable regardless of duration text.
- All other v1.4.0 strategy rules are unchanged.


## v1.4.2 — Univest recommendation-cycle dedupe

- Fixes same-stock same-day repeat recommendations after the earlier Univest recommendation has officially closed.
- A new eligible 1–3 month Univest equity recommendation now reserves the symbol immediately before BUY dispatch.
- Duplicate/repeated notifications are blocked while that recommendation is pending, active, averaging, re-entry waiting, or exiting.
- Once the official Univest exit completes and the state is EXITED, the same stock may be accepted again immediately as a new recommendation cycle, even if Univest reuses identical notification wording on the same day.
- Univest exits no longer use the generic 24-hour raw-notification fingerprint; the per-symbol state machine handles duplicate exits so a later recommendation cycle cannot have its legitimate exit suppressed.
- All Univest entries remain CASH/CNC DELIVERY only, with the 1–3 month duration gate unchanged. All Multyfi/manual strategy behavior is unchanged.


## v1.4.3 — Univest 2% averaging + safe delivery-exit reconciliation

- Univest downward averaging is now fixed at ₹5,000 at −2%, −4% and −6% from the original executed entry anchor, one GTT at a time.
- Before an automated Univest CNC MARKET SELL (official close or ₹2,500 NET capture), the app first cancels its tracked averaging/re-entry GTT, then clears any conflicting regular open/pending CASH/CNC SELL orders for that same symbol.
- The app re-lists orders after cancellation; if a conflicting sell is still active or cancellation state is uncertain, it does not send the market sell.
- After cleanup, the app fetches the current broker CNC position and sells only min(tracked Univest quantity, remaining broker CNC quantity). This avoids the prior "not enough shares" failure when a manual delivery sell order had reserved the shares.
- Univest remains 1–3 month equity entries only and always CASH/CNC DELIVERY; recommendation-cycle dedupe from v1.4.2 remains unchanged.


## v1.4.4 — Univest −10% broker protection + four 2% averages

- Every confirmed Univest CNC delivery entry immediately arms a separate broker-hosted CNC SELL GTT at 10% below the original first fill.
- The stop reference remains fixed to the original entry; averaging never moves the stop lower.
- Downward averaging remains ₹5,000 per add but is now capped at four levels: −2%, −4%, −6%, −8%. No fifth average is armed.
- After each averaging or re-entry fill, the protective stop quantity is updated to cover the full tracked Univest quantity.
- Official Univest exit and ₹2,500 NET profit capture must cancel both the BUY GTT and the protective SELL GTT before sending their market exit, avoiding duplicate SELL exposure.
- If the protective GTT triggers and broker quantity confirms its sale, the Univest recommendation cycle is closed and no further averaging occurs.
- Groww GTT uses a DOWN trigger with a CNC SELL MARKET post-trigger order. The 10% value is a trigger, not a guaranteed realized loss cap; fast markets can execute below the trigger.
- The 1–3 month duration filter, same-day new-cycle handling, delivery-only Univest rule, and Multyfi/manual logic remain unchanged.


## v1.4.5 — Univest −20% broker protection

- Protective broker-hosted Univest CNC SELL GTT moves from −10% to −20% from the original first executed entry price.
- The stop remains anchored to the original first fill and never moves lower after averaging.
- Protective GTT quantity is still resized to cover the full tracked Univest quantity after each confirmed average/re-entry fill.
- Downward averaging remains unchanged: four maximum ₹5,000 adds at −2%, −4%, −6% and −8% from the original first fill.
- Univest fast BUY and dedicated fast EXIT paths are unchanged.
- LG G7 ThinQ compatibility remains unchanged (minSdk 26; no native ABI dependency added).
- The −20% value is a trigger level, not a guaranteed realized-loss cap; a market order may fill lower during a gap/fast move.


## v1.4.6 — Univest BE-series symbol fix

- Fixes Univest recommendations displayed with an NSE `-BE` suffix, such as `HFCL-BE`.
- `HFCL-BE` is normalized to Groww/NSE trading symbol `HFCL` before reservation and order execution, so fast BUY and later EXIT use the same canonical state key.
- Groww official instrument-master filtering now permits both `EQ` and `BE` NSE CASH equity series while still rejecting F&O, options, futures, commodities and reserved/non-tradable instruments.
- Fast Univest BUY, dedicated fast EXIT, four averaging adds at −2/−4/−6/−8%, ₹2,500 net-profit capture, and the −20% protective broker GTT are unchanged.
- LG G7 ThinQ compatibility remains unchanged (minSdk 26; no native ABI dependency added).


## v2.0.1 Groww TOTP authentication fix
- Adds the mandatory X-API-VERSION: 1.0 header to the Groww TOTP access-token exchange.
- Clarifies TOTP token vs API key in the UI.
- Validates the Base32 TOTP secret and logs safe auth-stage diagnostics without exporting credentials.
